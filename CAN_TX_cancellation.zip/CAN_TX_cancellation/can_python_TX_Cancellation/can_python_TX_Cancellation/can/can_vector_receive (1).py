# INTEL CONFIDENTIAL
# Copyright 2024 Intel Corporation All Rights Reserved.
#
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and
# proprietary and confidential information of Intel Corporation and its
# suppliers and licensors, and is protected by worldwide copyright and trade
# secret laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery of
# the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing

import argparse
import contextlib

import can
from can.bus import BusState
from can.interfaces.vector import get_channel_configs


def print_message(can_message):
    out = f"Arbitration_id: {hex(can_message.arbitration_id)}\n"
    out += "Remote frame\n" if can_message.is_remote_frame else ""
    out += "Extended arbitration id frame\n" if can_message.is_extended_id else ""
    out += "Error frame\n" if can_message.is_error_frame else ""
    out += "Bitrate Switch\n" if can_message.bitrate_switch else ""
    out += f"Data_length: {len(can_message.data)}\n"
    out += f"data: {[hex(byte) for byte in can_message.data]}\n"
    print(out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Receive CAN frame",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--fd", action="store_true")
    parser.add_argument(
        "-c", "--can_bitrate", default=125000, help="CAN bitrate [bps]", type=int
    )
    parser.add_argument("-d", "--fd_bitrate", default=250000, help="FD bitrate [bps]", type=int)
    parser.add_argument(
        "-t", "--frame-timeout", default=2, help="Receiving frame Timeout", type=int
    )
    parser.add_argument(
        "-n", "--frames-number", default=1, help="Number of expected frames", type=int
    )
    parser.add_argument("--nsjw", help="Nominal sjw", type=int)
    parser.add_argument("--ntseg1", help="Nominal tseg 1", type=int)
    parser.add_argument("--ntseg2", help="Nominal tseg 2", type=int)
    parser.add_argument("--dsjw", help="Data sjw", type=int)
    parser.add_argument("--dtseg1", help="Data tseg 1", type=int)
    parser.add_argument("--dtseg2", help="Data tseg 2", type=int)

    args = vars(parser.parse_args())

    if args["fd"]:
        if args["nsjw"] is None:
            vector_bus = can.Bus(
                interface="vector",
                channel=0,
                bitrate=args["can_bitrate"],
                fd=True,
                data_bitrate=args["fd_bitrate"],
            )
        else:
            vector_bus = can.Bus(
                interface="vector",
                channel=0,
                bitrate=args["can_bitrate"],
                fd=True,
                data_bitrate=args["fd_bitrate"],
                sjw_abr=args["nsjw"],
                tseg1_abr=args["ntseg1"],
                tseg2_abr=args["ntseg2"],
                sjw_dbr=args["dsjw"],
                tseg1_dbr=args["dtseg1"],
                tseg2_dbr=args["dtseg2"],
            )
    else:
        if args["nsjw"] is None:
            vector_bus = can.Bus(interface="vector", channel=0, bitrate=args["can_bitrate"])
        else:
            f_clock = 16_000_000
            tq_per_bit = args["ntseg1"] + args["ntseg2"] + 1
            brp = int(f_clock / (args["can_bitrate"] * tq_per_bit))
            print(f"brp = {brp}")
            vector_bus = can.Bus(
                interface="vector",
                channel=0,
                f_clock=f_clock,
                brp=brp,
                tseg1=args["ntseg1"],
                tseg2=args["ntseg2"],
                sjw=args["nsjw"],
                nof_samples=1,
            )

    with vector_bus as vector_can:

        for config in get_channel_configs():
            if "Virtual" not in config.name:
                with contextlib.suppress(AttributeError):
                    print(str(config.bus_params.canfd))

        with contextlib.suppress(NotImplementedError):
            vector_bus.state = BusState.PASSIVE

        print(f"VECTOR STATE:{vector_can.state}")
        print("start receiving")
        frame_count = 0
        for _ in range(args["frames_number"]):
            msg = vector_can.recv(args["frame_timeout"])
            if msg:
                frame_count += 1
                print("=" * 80)
                print(f"Message nr {frame_count} received")
                print_message(msg)
                tryout = 0
                while tryout <= 64 and msg and msg.is_error_frame:
                    tryout += 1
                    print("-" * 80)
                    print(f"Message tryout: {tryout}")
                    msg = vector_can.recv(args["frame_timeout"])
                    print_message(msg)

        print("STOP RECEIVING")
