import time, sys, os
import log_file_framework as var_log_fw





try:
    var_script_name=sys.argv[0]
    var_log_fw.write_to_existing_file("Action | "+str(var_script_name)+" : Automation Script Execution Start")
    
    var_log_fw.write_to_existing_file("Action | Pre-Condition : Assuming : C:\Intel\DAL\ConfigConsole.exe is started, Correct Patform Selected and Connected (Green Color Showing)")                                                                    
    var_log_fw.write_to_existing_file("Action | Pre-Condition : Assuming : C:\Intel\DAL\PythonConsole.cmd is started, Correct Patform Displayed")                                                                    
    
    var_log_fw.write_to_existing_file("Action | Setting Python System Path to C:\Intel\DAL")                                  
    sys.path.append(r'C:\Intel\DAL')
    import itpii
    var_log_fw.write_to_existing_file("Action | itp=itpii.baseaccess() : Creating ITP Obje6ct")                                  
    itp=itpii.baseaccess()
    var_log_fw.write_to_existing_file("Action | Defining ITP Log File : itp.log("+str(var_log_fw.var_log_file_name_ITP)+")")                                  
    itp.log(var_log_fw.var_log_file_name_ITP)
    
    var_current_path = os.path.abspath(os.getcwd())
    var_ice_gen2_i3c_script_path = var_current_path.replace("automation","ice_gen2")
 
    sys.path.append(var_ice_gen2_i3c_script_path)
    var_log_fw.write_to_existing_file("Action | Setting Python System Path to "+str(var_ice_gen2_i3c_script_path))
    
    var_log_fw.write_to_existing_file("Action | lpss_ice_test_script : importing VICE SW I3C Test Code Library")
    from lpss_ice_test_script import *

    fpga_init()
    
    
    freq = 400
    speed =0
    init = True
    if(init==True):
        
        init_tc(port_num=1, slave_num=0, i2cni3c=0, dev_count=1)
        tc_swreset(port_num=1, slave_num=0, i2cni3c=0, dev_count=1)
       
        time.sleep(1)
        # init_master(i3c_num = 0,freq = freq, dyn_addr0=0x10,sta_addr0=0x0, lcnt_minusvalue=0 )
        # ice_reset(False)
        #ice_reset(False)
        #init_master(i3c_num = 0,freq = freq, dyn_addr0=0x10,sta_addr0=0x0, lcnt_minusvalue=0 )
         
        # check_present_state(i3c_num=0)
        #setaasa_lca(i3c_num = 0)
        # entdaa_lca(i3c_num = 0, hot_join=False,rstdaa=False)
        # check_present_state(i3c_num=0)
        # verify_daa(i3c_num = 0,dev_cnt=1, dev_indx = 0)
    
    
    from random import seed
    err=0
    #for i in range (0,1000):
    #for i in range (430,1000):
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        freq_list = range(400,2510,100)
        freq = 2000 #random.choice(freq_list)
        speed = 0 #random.randint(0,4)
        data_len = random.randint(16,512)
        #data_len_list = range(16,512,4)
        #data_len = random.choice(data_len_list)
        

        var_log_fw.write_to_existing_file("Action | ****** Iteration="+ str(i) + " seed=" + str(seed_id) + " ******\n" )
        
        #test_error_handling_inbound_qfull(freq=freq, speed=speed)
        
        #test_error_handling_invalid_mwl_with_dbgrst(freq=freq, speed=speed)
        
        #test_error_handling_dbgopcode_ccc_payload_greater_than_6(freq=freq, speed=speed)
        
        #test_concurrent_b2b_pvtwr(freq=freq, speed=speed, runtime_secs=30)
        
        # test_pvt_wr_txfr(freq=freq, speed=speed, data_len=data_len)  
        
        # test_rand3_dbgop_wr_getnext_wr_rd_dbgop_rd(freq=freq, speed=speed)
        #test_pvt_rd_txfr(freq=freq, speed=speed, data_len=data_len)#Sanity
        #( freq=freq, speed=speed, verbose=1)#Sanity
        
        #test_concurrent_b2b_pvtwr_rd(freq=freq, speed=speed, runtime_secs=30)
        
        
        var_log_fw.write_to_existing_file("Action | "+str(var_script_name)+" : Automation Script Execution End")
       

    #var_log_fw.write_to_existing_file("Action | "+str(var_script_name)+" : Automation Script Execution End")

except :
    # pass
    var_log_fw.write_to_existing_file('[ERROR - Master Thread - START] \n' + str(sys.exc_info()))
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    var_log_fw.write_to_existing_file( (exc_type, fname, exc_tb.tb_lineno) )
    var_log_fw.write_to_existing_file( '\n [ ERROR - Master Thread - END ]')