from enum import Enum
import itpii
import log_file_framework as var_log_fw
import can_reg; reload(can_reg)
itp = itpii.baseaccess()

import sys
import ctypes
import random
import time
import math

import itpii
import pci2
import os
import threading 
itp = itpii.baseaccess()

can0_bar = 0x50410000
can1_bar = 0x50418000

global can0
global can1
global CAN
#global readval
readval = 0
dev_bus = 3

DID_LIST = {
   
    'PTL' : {'0':{'DID':0x67B5, 'DEV': 0x1D, 'FUNC':0},'1':{'DID':0x67B6, 'DEV': 0x1D, 'FUNC':1}},
    
}

can0 = can_reg.regs(dev_bus, DID_LIST['PTL']['0']['DEV'],DID_LIST['PTL']['0']['FUNC'])
can1 = can_reg.regs(dev_bus, DID_LIST['PTL']['1']['DEV'],DID_LIST['PTL']['1']['FUNC'])
CAN =[can0, can1]



def readreg(address, size=4):
    
    value = itp.threads[0].mem((str(address) + 'p'), size)
    #print("In Read Reg***" + str(hex(address)) + " data= " + str(hex(value)) + "***")
    return value

def writereg(address, data, size=4):
    #print("In Write Reg***" + str(hex(address)) + " data= " + str(hex(data)) + "***")
    itp.threads[0].mem((str(address) + 'p'), size, data)
    return True

class Define_Value(Enum):
	FUNCTIONAL_CLOCK = 10000000
	CAN_CTRLMODE_FD = 0X08
	CAN_CTRLMODE_FD_BRS = 0X10
	CAN_CTRLMODE_CLASSIC = 0X04
	CAN_CTRLMODE_LISTENONLY = 0X02
	CAN_CTRLMODE_LOOPBACK = 0X01
	XIDFC_LSE_OFF = 16
	SIDFC_LSS_OFF = 16
	TIMEOUT_LIMIT = 10000

def clearRAM(m_bar = 0):
    print("Clearing message RAM")
    for i in range(4480):
        itp.threads[0].mem(str(m_bar + 0x800 + (i * 4)) + "p", 4, 0x0)
    print("--done")

def ReadRAM(m_bar = 0, addr=0, dw_count=0):
    global readval
    #readval = 0
    #print("Reading message RAM from addr = 0x%x"%addr)
    for i in range(dw_count):
        addr1 = addr + (i*4)
        readval = itp.threads[0].mem(str(m_bar + addr1) + 'p', 4)
        #readval = readreg(m_bar+addr)
        print("Read  MsgRAM[0x%x] = 0x%x"%(m_bar+addr1,readval))

def WriteRAM(m_bar=0, addr=0, data=0):
    #writereg(m_bar+addr,data)
    
    print("Write MsgRAM[0x%x] = 0x%x"%(m_bar+addr,data))
    itp.threads[0].mem((str(m_bar + addr) + 'p'), 4, data)
    

def MsgRAMTest(m_bar):
    print("Writing MsgRAM...")
    for i in range(4480):
        wrval = i #1180-->can_1
        WriteRAM(m_bar, 0x800+(i*4), wrval)
        rdval =  ReadRAM(m_bar, 0x800+(i*4),1)
        if(wrval == rdval):
            print("Mismatch at address 0x%x"%(0x800+(i*4)))
            #print("Match at address")
            return 0
    
def can_setup(m_bar = 0, rxf0c_elements = 0, rxf1c_elements = 0, rxbuff_elements=0, lss=0, lse = 0, flssa = 0, flesa = 0, eidm = 0, f0sa = 0, f1sa = 0, rbsa = 0, f0ds = 0, f1ds = 0, rbds = 0, efsa = 0, efs = 0, efwm = 0, tbsa = 0, ndtb = 0, tbqs = 0, tbqm = 0, tbds=0, fdoe = 0, brse = 0, ntseg2 = 0, ntseg1 = 0, nbrp = 0, nsjw = 0, fsjw = 0, ftseg2 = 0, ftseg1 = 0, fbrp = 0, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0, anfe = 0, anfs = 0, tie = 0, cfie = 0, eint0 = 0, eint1 = 0, intrLine = 0):

     
    reg_val_32 = 0
    
    # Step: 1
    can_end_communication(m_bar)
    
    '''
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffff7f) | (1 << 7)) # CCCR.TEST bit
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    
    # Step: _default
    
    print("Tako: " + str(can0.TEST.offset))
    reg_val_32 = readreg(m_bar + can0.TEST.offset)
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x0 << 4))
    writereg(m_bar + can0.TEST.offset, reg_val_32)
    '''
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)

    

    # Step: 2
    reg_val_32 = readreg(m_bar + can0.SIDFC.offset)
    # No need to shift address by 2 - FLSSA[15:2]: Filter List Standard Start Address
    #reg_val_32 = ((reg_val_32 & 0xffff0003) | ((m_bar + flssa + 0x800) << 2)) #baseaddr+0x800 
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800)) #0x800
    #reg_val_32 = ((reg_val_32 & 0xffff0003) | flssa) #0x800
    reg_val_32 = ((reg_val_32 & 0xff00ffff) | (lss << 16)) #128 or any
    writereg(m_bar + can0.SIDFC.offset, reg_val_32) 
    
    reg_val_32 = readreg(m_bar + can0.XIDFC.offset)
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4))) #baseaddr+0x800+128
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (lse << 16)) #128 or any
    writereg(m_bar + can0.XIDFC.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.XIDAM.offset)
    reg_val_32 = ((reg_val_32 & 0xe0000000) | eidm)
    writereg(m_bar + can0.XIDAM.offset, reg_val_32)
    
    rxf0ElementSize = 8 + f0ds * 4
    if f0ds == 5:
        rxf0ElementSize = 32
    elif f0ds == 6:
        rxf0ElementSize = 48
    elif f0ds == 7:
        rxf0ElementSize = 64
    reg_val_32 = readreg(m_bar + can0.RXF0C.offset)
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4) + (lse * 2 * 4)) )
    reg_val_32 = ((reg_val_32 & 0xff80ffff) | (rxf0c_elements << 16))
    writereg(m_bar + can0.RXF0C.offset, reg_val_32)
    
    rxf1ElementSize = 8 + f1ds * 4
    if f1ds == 5:
        rxf1ElementSize = 32
    elif f1ds == 6:
        rxf1ElementSize = 48
    elif f1ds == 7:
        rxf1ElementSize = 64
    
    reg_val_32 = readreg(m_bar + can0.RXF1C.offset)
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4) + (lse *2 * 4) + 
                                                (rxf0c_elements * (rxf0ElementSize + 8))))
    reg_val_32 = ((reg_val_32 & 0xff80ffff) | (rxf1c_elements << 16))
    writereg(m_bar + can0.RXF1C.offset, reg_val_32)
    
    rxbufElementSize = 8 + rbds * 4
    if rbds == 5:
        rxbufElementSize = 32
    elif rbds == 6:
        rxbufElementSize = 48
    elif rbds == 7:
        rxbufElementSize = 64
    
    reg_val_32 = readreg(m_bar + can0.RXBC.offset)
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4) + (lse * 2 * 4) + 
                                               (rxf0c_elements * (rxf0ElementSize + 8)) + 
                                               (rxf1c_elements * (rxf1ElementSize + 8))) )
    
    reg_val_32 = ((reg_val_32 & 0xff80ffff) | (rxbuff_elements  << 16))    
    writereg(m_bar + can0.RXBC.offset, reg_val_32)
    
    
    reg_val_32 = readreg(m_bar + can0.RXESC.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffff8) | f0ds)
    reg_val_32 = ((reg_val_32 & 0xffffff8f) | (f1ds << 4))
    reg_val_32 = ((reg_val_32 & 0xfffff8ff) | (rbds << 8))
    writereg(m_bar + can0.RXESC.offset, reg_val_32)
    
    
    
    
    reg_val_32 = readreg(m_bar + can0.TXEFC.offset)
    
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4) + (lse * 2 * 4) + 
                                               (rxf0c_elements * (rxf0ElementSize + 8)) + 
                                               (rxf1c_elements * (rxf1ElementSize + 8)) +
                                               (rxbuff_elements * (rxbufElementSize + 8))))
    
        
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (efs << 16))
    reg_val_32 = ((reg_val_32 & 0xc0ffffff) | (efwm << 24))
    writereg(m_bar + can0.TXEFC.offset, reg_val_32)
    
    
    
    
    reg_val_32 = readreg(m_bar + can0.TXBC.offset)
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (flssa + 0x800 + (lss * 4) + (lse * 2 * 4) + 
                                               (rxf0c_elements * (rxf0ElementSize + 8)) + 
                                               (rxf1c_elements * (rxf1ElementSize + 8)) +
                                               (rxbuff_elements * (rxbufElementSize + 8))+
                                               (efs*8)))
    
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (ndtb << 16))
    reg_val_32 = ((reg_val_32 & 0xc0ffffff) | (tbqs << 24))
    reg_val_32 = ((reg_val_32 & 0xbfffffff) | (tbqm << 30))
    writereg(m_bar + can0.TXBC.offset, reg_val_32)
    
    #added
    '''
    Set the size of the data field of the Tx buffer with the 
    Tx Buffer Element Size Configuration (TXESC) register
    '''
    reg_val_32 = readreg(m_bar + can0.TXESC.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffc) | tbds )
    writereg(m_bar + can0.TXESC.offset, reg_val_32)
    
    
    
    
    #clearRAM(m_bar)
    
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffeff) | (fdoe << 8))
    reg_val_32 = ((reg_val_32 & 0xfffffdff) | (brse << 9))
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.NBTP.offset)
    reg_val_32 = ((reg_val_32 & 0xffffff80) | ntseg2)
    reg_val_32 = ((reg_val_32 & 0xffff80ff) | (ntseg1 << 8))
    reg_val_32 = ((reg_val_32 & 0xfe00ffff) | (nbrp << 16))
    reg_val_32 = ((reg_val_32 & 0x01ffffff) | (nsjw << 25))
    writereg(m_bar + can0.NBTP.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.DBTP.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffff0) | fsjw)
    reg_val_32 = ((reg_val_32 & 0xffffff0f) | (ftseg2 << 4))
    reg_val_32 = ((reg_val_32 & 0xffffe0ff) | (ftseg1 << 8))
    reg_val_32 = ((reg_val_32 & 0xffe0ffff) | (fbrp << 16))
    reg_val_32 = ((reg_val_32 & 0xff7fffff) | (tdc << 23))
    writereg(m_bar + can0.DBTP.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.TDCR.offset)
    reg_val_32 = ((reg_val_32 & 0xffffff80) | tdcf)
    reg_val_32 = ((reg_val_32 & 0xffff80ff) | (tdco << 8))
    writereg(m_bar + can0.TDCR.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.GFC.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | rrfe)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (rrfs << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffff3) | (anfe << 2))
    reg_val_32 = ((reg_val_32 & 0xffffffcf) | (anfs << 4))
    writereg(m_bar + can0.GFC.offset, reg_val_32)
    
    
    '''
	8. To enable Tx buffers to assert an interrupt upon transmission, 
    configure the Tx Buffer Transmission Interrupt Enable (TXBTIE) register. 
    Similarly, for Tx buffers to assert an interrupt upon completion of transmission cancellation, 
    configure the Tx Buffer Cancellation Finished Interrupt Enable (TXBCIE) register. 
    Clear the interrupt flags in the Interrupt Register (IR) and 
    enable each interrupt in the Interrupt Enable (IE) register. 
    The CAN FD Controller has dual interrupt lines; 
    Interrupt Line Select (ILS) determines the line the interrupt is assigned to. 
    Enable the interrupt line with Interrupt Line Enable (ILE). 

    '''
    
    reg_val_32 = readreg(m_bar + can0.TXBTIE.offset)
    reg_val_32 = ((reg_val_32 & 0x00000000) | tie)
    writereg(m_bar + can0.TXBTIE.offset, reg_val_32)
    
    reg_val_32 = readreg(m_bar + can0.TXBCIE.offset)
    reg_val_32 = ((reg_val_32 & 0x00000000) | cfie)
    writereg(m_bar + can0.TXBCIE.offset, reg_val_32)
    
    #added
    #Clear intr flags in IR
    reg_val_32 = readreg(m_bar + can0.IR.offset)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0xFFFFFFFF)
    writereg(m_bar + can0.IR.offset, reg_val_32)
    
    #Enable all intr flags in IE
    reg_val_32 = readreg(m_bar + can0.IE.offset)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0xFFFFFFFF)
    writereg(m_bar + can0.IE.offset, reg_val_32)
    
    
    if ((intrLine == 0x00000000) or (intrLine == 0x00000001)):
        reg_val_32 = readreg(m_bar + can0.ILE.offset)
        if (intrLine == 0x00000000):
            reg_val_32 = ((reg_val_32 & 0xfffffffe) | eint0)
        elif (intrLine == 0x00000001):
            reg_val_32 = ((reg_val_32 & 0xfffffffd) | (eint1 << 1))
        writereg(m_bar + can0.ILE.offset, reg_val_32)
    
    #  TODO: Frame packets (filter configuration, tx buffer)
    #  TODO: IPSV to figure out how to initialize the Rx buffer
    
    can_start_communication(m_bar)
    print("Done with can_setup")
    #can0.readall()

def can_end_communication(m_bar = 0):
    
    reg_val_32 = 0

    # Step: _default
    #reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    time.sleep(2)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)


def can_start_communication(m_bar = 0):
    
    count = 0
    reg_val_32 = 0
    _PollCount = 0
    _tmp = 0
    _pvar = 0

    # Step: _default
    count = 10000
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    '''
    while True:
        _tmp = readreg(m_bar + can0.CCCR.offset)
        _pvar = (_tmp & 0x00000001)
        _PollCount += 1
        if (_PollCount >= 10000):  # check max count
            print " ERROR | Hit Maximum count:10000 (LocalRef(e, RF<canss_top/m_can_inst_0/m_can_reg0_can0_mmio_i/m_can0_mmio_sub_MEM>) == BitVectorConst(True, True, BitVector<1>))"
        if (_pvar == 0x1):
            break
    '''
    
def getNumBytes(dlc = 0):

    ret = 0
    i = 0

    # Step: _default
    if (dlc <= 0x8):
        return dlc
    if(dlc>8 and dlc<13):
        ret = (((dlc - 0x08) * 0x04) + 0x08) #9=12B, 10=16B, 11=20B, 12=24B, 13=32B, 14=48B, 15=64B
        return ret
    #ret = (((dlc - 0x08) * 0x08) + 0x08) #9=12B, 10=16B, 11=20B, 12=24B, 13=32B, 14=48B, 15=64B
    if dlc == 13:
        ret = 32
        return ret
    if dlc == 14:
        ret = 48
        return ret
    if dlc == 15:
        ret = 64
        return ret
    else :
        print("Not a valid dlc")
    return ret

 
def start_tx(m_bar=0,xtd = 0,fdf = 0,brs=0,dlc=8,start_val=1):
      
    # Step: 1
      
    
    
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffbf) | (1 << 6)) # CCCR.DAR bit (Disable auto re-transmission)
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    
    
    
    '''
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffff7f) | (1 << 7)) # CCCR.TEST bit
    #reg_val_32 = ((reg_val_32 & 0xfffffffDf) | (1 << 5)) # CCCR.MON bit Internal Loopback
    #reg_val_32 = ((reg_val_32 & 0xfffffffDf) | (0 << 5)) # CCCR.MON bit External loopback
    
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    '''
    
    reg_val_32 = readreg(m_bar + can0.TEST.offset)
    #reg_val_32 = ((reg_val_32 & 0xffffffef) | (0 << 4)) #LBCK bit
    #writereg(m_bar + can0.TEST.offset, reg_val_32)
    #reg_val_32 = readreg(m_bar + can0.TEST.offset)
    
    
    
    
    txbuf = []
    can_id = 0x6A5#random.getrandbits(29)
    rtr = 0
    #xtd = 0
    esi = 0
    mm = 0x1
    
    #dlc = 8
    #brs = 0
    #fdf = 0
    tsce = 0
    efc = 1
    #data0 = 0x04030201
    #data1 = 0x08070605
    
    
    
    #start_val = 0x20
    
    #data0 =((start_val+3)<<24)|((start_val+2)<<16)| ((start_val+1)<<8) | start_val
    #data1 =((start_val+7)<<24)|((start_val+6)<<16)| ((start_val+5)<<8) | start_val+4    
    
    #data0 = random.getrandbits(32) #0x900dbaAC
    #data1 = random.getrandbits(32) #0x0807BADD
    #data0 = 0x900d900d
    #data1 = 0xABCDABCD
    
    #data0 = 0xab
    #data1 = 0x11223344
    
    #data0 = 0xAAAAAAAA
    #data1 = 0xAAAAAAAA
    
    #if(fdf==0 and xtd==0):
    if(xtd==0):
        can_id1 = can_id <<18
    else:
        can_id1 = can_id
    
    t0 = (esi << 31) | (xtd <<30) | (rtr<<29) | can_id1
    t1 = ((mm & 0xFF) <<24) | (efc<<23) | (tsce<<22) | (fdf<<21) | (brs<<20) | (dlc << 16) | ((mm>>8 & 0xFF)<<8) 
    #t2 = data0
    #t3 = data1
        
    txbuf.append(t0)
    txbuf.append(t1)
    
    
    num_bytes = getNumBytes(dlc)
    
    
    
    num_dword = num_bytes/4
    num_remain = num_bytes%4
    print("num_bytes = %d, num_dword=%d, num_remain=%d"%(num_bytes,num_dword,num_remain))
    #start_val = 0x20
    
    for idx in range(num_dword):
        offset = idx * 4
        #data =tx_data[offset+3] << 12 | tx_data[offset+2] << 8 | tx_data[offset+1] << 4 | tx_data[offset]
        #data =tx_data[offset+3] << 24 | tx_data[offset+2] << 16 | tx_data[offset+1] << 8 | tx_data[offset]
        data =((start_val+3)<<24)|((start_val+2)<<16)| ((start_val+1)<<8) | start_val
        txbuf.append(data)
        start_val +=4
    data = 0
    offset = num_dword*4
    if num_remain:
        for idx in range(num_remain):
            #data = data | (tx_data[idx + offset])<<(idx*8)
            data = data | (start_val+idx)<<(idx*8)
            
        txbuf.append(data)
        
        
    #txbuf.append(t2)
    #txbuf.append(t3)
    
    
    
    for i in range(0,len(txbuf)):
        print("Writing Tx Buffer[%d] = 0x%x"%(i,txbuf[i]))
        WriteRAM(m_bar, 0x4300+(i*4),txbuf[i])
        ReadRAM(m_bar,0x4300+(i*4),1)
        
   
   
     
    
    '''
    sft = 0 #2 #0
    sfec = 1
    sfid1 = 0x1 #can_id#0x0
    sfid2 = 0x7FF
    ssync = 0
    
    std_11bit_filter = (sft<<30) | (sfec<<27) | (sfid1 <<16) | (ssync << 15) | sfid2
    ReadRAM(m_bar,0x800,1)
    WriteRAM(m_bar, 0x800,std_11bit_filter)
    ReadRAM(m_bar,0x800,1)
    
    ## EXtended ID fileter config
    efec = 2  #stores in RXFIFO1
    efid1 = 0x1
    efid2 = 0x3FFFFFFF
    eft   = 0
    esync = 0
    
    ext_29bit_filter_dw0 = (efec<<29) | (efid1)
    ext_29bit_filter_dw1 = (eft<<30) | (esync<<29)|(efid2)
    ReadRAM(m_bar,0xA00,1)
    WriteRAM(m_bar, 0xA00,ext_29bit_filter_dw0)
    ReadRAM(m_bar,0xA00,1)
    ReadRAM(m_bar,0xA04,1)
    WriteRAM(m_bar, 0xA04,ext_29bit_filter_dw1)
    ReadRAM(m_bar,0xA04,1)
    
    '''
    
    #can_start_communication(m_bar)
    
    reg_val_32 = readreg(m_bar + can0.TXBAR.offset)
    reg_val_32 = ((reg_val_32 & 0xffffffe) | 1) #txbuf0,1 bit
    writereg(m_bar + can0.TXBAR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.TXBAR.offset)
    
    print("Done with start_tx")
    
    
    
    time.sleep(1)
    print("\n")
    
    reg_val_32 = readreg(m_bar + can0.IR.offset)
    print("IR Value",reg_val_32)
    _PollCount = 0
    _pvar = 0
    
    while True:
        _tmp = readreg(m_bar+can0.IR.offset)
        print("_pvar",_tmp)
        _pvar = ((_tmp & 0x00000200) >> 9)
        print("_pvar",_pvar)
        _PollCount += 1
        if(_PollCount >= 30):
            print ("ERROR | Hit Maximum count:30 (IR == BitVector<1>")
            break
        if (_pvar == 0x1):
            print("Interrupt register is set")
            readreg(m_bar+can0.TXBRP.offset)
            readreg(m_bar+can0.TXBTO.offset)
            readreg(m_bar+can0.TXBAR.offset)
            break
    
    '''
    ReadRAM(m_bar,0x800,1)
    
    print("Reading MsgRAM Tx Buffer")
    ReadRAM(m_bar, 0x4300, 4)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    ReadRAM(m_bar, 0x4200, 4)
    print("\n")
    
    #m_bar = 0x50418000
    print("Reading MsgRAM Rx Buffer")
    ReadRAM(m_bar, 0x3000, 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    ReadRAM(m_bar, 0xC00, 4)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    ReadRAM(m_bar, 0x1E00, 4)
    print("\n")
    '''

    
def start_rx(m_bar=0):
      
    # Step: 1
    #can_end_communication(m_bar)
    
    '''
    writereg(m_bar + can0.CCCR.offset, 0x1)
    writereg(m_bar + can0.CCCR.offset, 0x3)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    
    
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffbf) | (1 << 6)) # CCCR.DAR bit (Disable auto re-transmission)
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    '''
    '''
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffff7f) | (1 << 7)) # CCCR.TEST bit
    #reg_val_32 = ((reg_val_32 & 0xfffffffDf) | (1 << 5)) # CCCR.MON bit Internal Loopback
    #reg_val_32 = ((reg_val_32 & 0xfffffffDf) | (0 << 5)) # CCCR.MON bit External loopback
    
    writereg(m_bar + can0.CCCR.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.CCCR.offset)
    '''
    
    '''
    reg_val_32 = readreg(m_bar + can0.TEST.offset)
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (1 << 4)) #LBCK bit
    writereg(m_bar + can0.TEST.offset, reg_val_32)
    reg_val_32 = readreg(m_bar + can0.TEST.offset)
    '''
    
    ## Standard ID filter config   
    sft = 0 #2 #0
    sfec = 1 #7
    sfid1 = 0x1 #can_id#0x1
    sfid2 = 0x7FF
    ssync = 0
    
    std_11bit_filter = (sft<<30) | (sfec<<27) | (sfid1 <<16) | (ssync << 15) | sfid2
    ReadRAM(m_bar,0x800,1)
    WriteRAM(m_bar, 0x800,std_11bit_filter)
    ReadRAM(m_bar,0x800,1)
    
    ## EXtended ID filter config
    eft   = 0
    efec = 2  #stores in RXFIFO1
    efid1 = 0x1
    efid2 = 0x3FFFFFFF
    esync = 0
    
    ext_29bit_filter_dw0 = (efec<<29) | (efid1)
    ext_29bit_filter_dw1 = (eft<<30) | (esync<<29)|(efid2)
    ReadRAM(m_bar,0xA00,1)
    WriteRAM(m_bar, 0xA00,ext_29bit_filter_dw0)
    ReadRAM(m_bar,0xA00,1)
    ReadRAM(m_bar,0xA04,1)
    WriteRAM(m_bar, 0xA04,ext_29bit_filter_dw1)
    ReadRAM(m_bar,0xA04,1)
    
    #can_start_communication(m_bar)
    
    print("Done with start_rx")





    
def read_ram_buffers(m_bar=0,dlc=8):
    
    if(m_bar == 0x50410000):
        print("\n***** CAN0 MsgRAM Buffer Dump *****")
    else:
        print("\n***** CAN1 MsgRAM Buffer Dump *****")
    
    reg_val_32 = readreg(m_bar + can0.IR.offset)
    
    num_bytes = getNumBytes(dlc)
   
    num_dword = num_bytes/4
    num_remain = num_bytes%4
    if(num_remain>0):
        num_dword+=1
        
    num_dword+=2 #for header
    
    print("Reading MsgRAM 11bit filter")
    ReadRAM(m_bar,0x800,1)
    print("\n")
    
    print("Reading MsgRAM 29bit filter")
    ReadRAM(m_bar,0xA00,2)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    ReadRAM(m_bar, 0x4300, num_dword)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    ReadRAM(m_bar, 0x4200, 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    ReadRAM(m_bar, 0x3000, num_dword)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    ReadRAM(m_bar, 0xC00, num_dword)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    ReadRAM(m_bar, 0x1E00, num_dword)
    print("\n")
    
    reg_val_32 = readreg(can0_bar + can0.PSR.offset)
    print("CAN-0 PSR Value",reg_val_32)
    print("\n")
    reg_val_32 = readreg(can1_bar + can0.PSR.offset)
    print("CAN-1 PSR Value",reg_val_32)
 
def register_write(m_bar = 0):
        
    # Step: 1
    can_end_communication(m_bar)
    
    #Read TEST Register
    '''
    reg_val_32 = readreg(m_bar + can0.SIDFC.offset)
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x0 << 4))
    writereg(m_bar + can0.SIDFC.offset, reg_val_32)
    print("SIDFC =0x%X" % (can0.SIDFC.read()))
    reg_val_32 = 0x0 #((reg_val_32 & 0xffffffef) | (0x0 << 4))
    writereg(m_bar + can0.SIDFC.offset, reg_val_32)
    print("SIDFC after writing all zero =0x%X" % (can0.SIDFC.read()))
    '''
    reg_val_32 = readreg(m_bar + can0.SIDFC.offset)
    # No need to shift address by 2 - FLSSA[15:2]: Filter List Standard Start Address
    #reg_val_32 = ((reg_val_32 & 0xffff0003) | ((m_bar + flssa + 0x800) << 2)) #baseaddr+0x800 
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (0 + 0x800)) #baseaddr+0x800
    reg_val_32 = ((reg_val_32 & 0xff00ffff) | (128 << 16)) #128 or any
    writereg(m_bar + can0.SIDFC.offset, reg_val_32)
    print("SIDFC =0x%X" % (can0.SIDFC.read()))
    reg_val_32 = 0x0 #((reg_val_32 & 0xff00ffff) | (128 << 16)) #128 or any
    writereg(m_bar + can0.SIDFC.offset, reg_val_32)
    print("SIDFC after all write 0 =0x%X" % (can0.SIDFC.read()))
    reg_val_32 = ((reg_val_32 & 0xffff0003) | (0 + 0x800)) #baseaddr+0x800
    reg_val_32 = ((reg_val_32 & 0xff00ffff) | (128 << 16)) #128 or any
    writereg(m_bar + can0.SIDFC.offset, reg_val_32)
    print("SIDFC =0x%X" % (can0.SIDFC.read()))
    can_start_communication(m_bar)
    

def MsgRAMTest(m_bar = 0):
    #global readval
    #readval = 0
    print("Writing MsgRAM...")
    for i in range(4480):
        wrval = i+10 #1180-->can_1
        WriteRAM(m_bar, 0x800+(i*4), wrval)
        ReadRAM(m_bar, 0x800+(i*4),1)
        #print("wrval",wrval)
        print("rdval",readval)
        if(wrval != readval):
            print("Mismatch at address 0x%x"%(0x800+(i*4)))
        else:
            print("Match at address")
            #return 0
    


