###Author: chia.kian.puan@intel.com  --- VICE LPSS SV
## PLEASE DO NOT EDIT ANY of the function. If u want to do so, please inform me. Thank you.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import sys
import ctypes
import random
import time
import math

import itpii
import pci2
import os
import threading 
itp = itpii.baseaccess()



#import my_lib;reload (my_lib)

import log_file_framework as var_log_fw
import can_reg; reload(can_reg)

import CanDeviceLibrary as CanDeviceLibrary





var_log_ALL=4
var_log_INFORMATION=3
var_log_DEBUG=2
var_log_ERROR=1
var_log_CRITICAL=0

start_time = 0

#Default Assignment

var_log_level_SET=var_log_ALL
#Faster Execution, Restricted Log Level
#var_log_level_SET=var_log_DEBUG



def log_print(var_log_level=var_log_ALL, var_log_line=''):
    if var_log_level <= var_log_level_SET:
        var_log_fw.write_to_existing_file(var_log_line)

log_print(var_log_INFORMATION,str(sys.argv[0]) + " command line arguments : " + str(sys.argv))

# for current func name, specify 0 or no argument.
# for name of caller of current func, specify 1.
# for name of caller of caller of current func, specify 2. etc.
currentFuncName = lambda n=0: sys._getframe(n + 1).f_code.co_name

DID_LIST = {
   
    'PTL' : {'0':{'DID':0x67B5, 'DEV': 0x1D, 'FUNC':0},'1':{'DID':0x67B6, 'DEV': 0x1D, 'FUNC':1}},
    
    }

global prj 
prj = 'PTL'


global CAN
global can0
global can1


mem_src = 0x1000000
mem_dst = 0x2000000



bus=0x09
device=0x1D
func=0x0
func_can1=0x1



def dump_mem (base, length, size=4):
    # itp.threads[0].memdump(str(base)+'p' , str(length)+'p', size)
    itp.threads[0].memdump(str(base)+'p' , length, size)
    return
    

def readMem(address, size=4):
    value = itp.threads[0].mem((str(address) + 'p'), size)
    return value

def writeMem(address, data, size=4):
    itp.threads[0].mem((str(address) + 'p'), size, data)
    return True


def readCfg(bus,device,func,offset):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    value = itp.threads[0].dport(0xcfc)
    return value

def writeCfg(bus,device,func,offset, data):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    itp.threads[0].dport(0xcfc, data)
    return True


##############function to re-initiate project
def fpga_init(proj=prj,verbose= 0):

    global PROJECT

    found = False
 
    #loop to scan bus and identify where the TSN is located
    for i in range(2,23):
        #open PCI cfg space for TSN.
        if(verbose):
            log_print(var_log_INFORMATION, "Open PCI Cfg for B:D:F = %d,0x%x,0x%x\n" % (i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC']))
            
        pci2.OpenPciCfg(i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
        #pci2.OpenPciCfg(i,DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
        
        didread = pci2.ReadPciCfgBits(0x0,31,16)

        pci2.ClosePciCfg()

        if((didread & 0xffff) == DID_LIST[proj]['0']['DID']):  
            log_print(var_log_INFORMATION, "Detected CAN FPGA for %s with DID = 0x%x on bus number = 0x%x\n" %(proj,DID_LIST[proj]['0']['DID'],i))
            found = True
            dev_bus = i
            break
   
    if(not found):
        log_print(var_log_INFORMATION, "ERROR | Did not manage to find any CAN controller\n")
        return 1
        
    
    
    #print I3C
    global CAN
    global can0
    global can1

  
        

    can0 = can_reg.regs(dev_bus, DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
    can1 = can_reg.regs(dev_bus, DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
    CAN =[can0, can1]
    
    
    log_print(var_log_INFORMATION, "MSG_RAM_SIZE =0x%X" % (can0.MSG_RAM_SIZE.read()))
    #log_print(var_log_INFORMATION, "MAC_Version =0x%X" % (can0.MAC_Version.read()))
    #log_print(var_log_INFORMATION, "CSR =0x%X" % (tsn0.CSR.read()))
    
   

    
        
    
    log_print(var_log_INFORMATION, "SUCCESS | FPGA Initialization complete\n")
    
    return


def can_init():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 1, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = 1, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)

def can_init_old():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 2, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
  
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    
        
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
               
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can0_bar, can0.IR.offset)
    print("IR TxEventFIFO - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
    
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can0_bar, can0.IR.offset)
    print("IR TxEventFIFO - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")      
    
    
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 8)
    print("\n")
    
    
    
def can_init_extd_filter():
    
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    '''
    print("this is my first sequence")
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x01, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x01, ssync = 0, sfid2 = 0x0)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 7, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    '''
    print("this is my second sequence")
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1fffffff, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    '''
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    '''
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=15555555, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)

    #val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x3d, ssync = 0, sfid2 = 0x0)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x02, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 2, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 20)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 8)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
def can_init_old():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)

    #single Packet
    
    """
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFF, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0) 
    
    """
    
    # Multiple packet
    """
   
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
   """
   
    #RX buffer
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x07, efid1 = 0x1, esync = 0x0, efid2 = 0)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x07, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 200)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 140)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 140)
    print("\n")
    
    
    CanDeviceLibrary.ReadFilterPriority(m_bar = m_bar)


    
    print("Reading MsgRAM Rx Filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x200), dw_count = 4)
    print("\n")
    
    



    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
def can_init_extd_filter():
    
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    '''
    print("this is my first sequence")
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x01, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x01, ssync = 0, sfid2 = 0x0)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 7, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    '''
    print("this is my second sequence")
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1fffffff, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    '''
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    '''
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=15555555, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)

    #val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x3d, ssync = 0, sfid2 = 0x0)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x02, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 2, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 20)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 8)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    

def Vector_to_CAN0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 31
    ntseg2 = 8
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x20)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("send packet from Vector...")
    time.sleep(30)
    
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''

def Vector_to_CAN1():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    print("send packet from Vector...")
    time.sleep(30)
    
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
def Vector_to_CAN1_CAN0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 1, ssync = 0, sfid2 = 0x2)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x3, ssync = 0, sfid2 = 0x4)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
    

    
def No_Receiver():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 127
    ntseg2 = 32
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)


    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    

def Test_Case_14():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 16
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    efec = 2
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7;
    sfid1 = 0
    efid1 = 0
    ssync = 0
    sfid2 = 0
    efid2 = 0
    #filt = 0
    val = 0
    
    
    
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = efec, efid1 = 0, esync = 0x0, efid2 = 0x1FFF0000)
    CanDeviceLibrary.push29BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")
    

    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''   
    
    
    
    
def Test_Case_21():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    #sfec = random.choice(sfec_values)
    sfec = 2
    efec = 2
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    #can_id = 0x7;
    sfid1 = 0
    efid1 = 0
    ssync = 0
    sfid2 = 0
    efid2 = 0
    #filt = 0
    val = 0
    
    
    
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = efec, efid1 = 0, esync = 0x0, efid2 = 0x1FFF0000)
    #CanDeviceLibrary.push29BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    #setwatermark
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    
        
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
               
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    for i in range(4):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = i)
    
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
 
  
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")  
                   
   
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can0_bar, can0.IR.offset)
    print("IR TxEventFIFO can0_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")  
                      
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
 
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR TxEventFIFO - After verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")  
                   
 
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x3A00), dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")  
    
    print("Reading TXEFS")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.TXEFS.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n") 
    
    print("Reading PSR")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.PSR.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n") 

def arbitration():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
   
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)  
    
    
    
    '''
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    '''
    CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, 0x7)
    
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    

    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")

    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
 
   
    
def can_init_can1_to_can0_ackerror():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    #can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    
   
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 3, txbuf = txbuf)
    
                          
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 4, txbuf = txbuf)
    
        
    
    for i in range(4):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = i)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
     
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO can0_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
       
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR TxEventFIFO can1_bar - After verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
       
    print("Reading TXEFS")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.TXEFS.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n") 
    
    print("Reading PSR")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.PSR.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n") 
        
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 40)
    print("\n")
    
   
    
def Test_Case_21_can1_to_can0_watermark():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can1_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
       
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 0 , loopback_enable  = 0)
    
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 2, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
  
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    
        
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
               
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 3, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 4, txbuf = txbuf)
    
    for i in range(4):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = i)
    
    
    print("Reading IR TxEventFIFO ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO can0_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
    
    print("Reading IR TxEventFIFO ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR TxEventFIFO can1_bar - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
       
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    
    
    print("Send packets after packets are drined")
    txbuf = CanDeviceLibrary.createTxPacket(can_id=10, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 5)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 5, txbuf = txbuf)
    
    #for i in range(4):
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 5)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=11, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 6)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 6, txbuf = txbuf)
    
    #for i in range(4):
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 6)
    
    
    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR after packets are sent ", reg_val_32)
    print("\n")    

        
    
    
    
  
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 120)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO - After verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")
    
 
def TX_side_loop_back_watermark():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
  
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    
        
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
               
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
       
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    for i in range(4):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = i)
    
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO - verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    
    
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=10, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 5)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 5, txbuf = txbuf)
    
    #for i in range(4):
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 5)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=11, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 6)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 6, txbuf = txbuf)
    
    #for i in range(4):
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 6)
    
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO - Before verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")    

    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO - After verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")      
    
    
    
  
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 120)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")
    
    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO - After verify_rx_transceiver. reg_val_32 is", reg_val_32)
    print("\n")
    
    
def can_init_can1_to_can0_Transceiver():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 5, efwm = 4, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 5, efwm = 4, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    for i in range(6):
        txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = i, txbuf = txbuf)
    for i in range(6):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = i)

    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR can0_bar - reg_val_32 is", reg_val_32)
    print("\n")    
    
    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR can1_bar - reg_val_32 is", reg_val_32)
    print("\n")  
   
    print("Reading TXEFS ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXEFS.offset)
    print("TXEFS can1_bar - Before verify_rx_tranceiver reg_val_32 is", reg_val_32)
    print("\n")  
        
    CanDeviceLibrary.verify_rx_tranceiver_canX_to_canY(Tx_can_bar = can1_bar, Rx_can_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf, pos=0)
    #CanDeviceLibrary.verify_rx_tranceiver_canX_to_canY(Tx_can_bar = can1_bar, Rx_can_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf, pos=0)
  
    print("Reading TXEFS ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXEFS.offset)
    print("TXEFS can1_bar - After verify_rx_tranceiver reg_val_32 is", reg_val_32)
    print("\n")  
            
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")    
    
    
    for i in range(1):
        txbuf = CanDeviceLibrary.createTxPacket(can_id=i+8, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = i, txbuf = txbuf)
    for i in range(1):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = i)    

  
    print("Reading TXEFS ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXEFS.offset)
    print("TXEFS can1_bar - After verify_rx_tranceiver reg_val_32 is", reg_val_32)
    print("\n")  
            
    
    print("Reading MsgRAM Tx Buffer - After send some more packets")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 60)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")    
    
def Test_case_22_can_init_can1_to_can0_Transceiver_at_Rx_side():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 3, rxf1c = 0, rxf1c_elements = 3, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 32, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 3, rxf1c = 0, rxf1c_elements = 3, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 32, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    for i in range(5):
        txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = i, txbuf = txbuf)
    for i in range(5):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = i)

    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR can0_bar - reg_val_32 is", reg_val_32)
    print("\n")    
    
    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.IR.offset)
    print("IR can1_bar - reg_val_32 is", reg_val_32)
    print("\n")  
   
    print("Reading RXF0S ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.RXF0S.offset)
    print("TXEFS can1_bar - Before verify_rx_tranceiver reg_val_32 is", reg_val_32)
    print("\n")  
        
    CanDeviceLibrary.verify_rx_tranceiver_canX_to_canY(Tx_can_bar = can1_bar, Rx_can_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf, pos=0)
    #CanDeviceLibrary.verify_rx_tranceiver_canX_to_canY(Tx_can_bar = can1_bar, Rx_can_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf, pos=0)
  
    print("Reading RXF0S ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.RXF0S.offset)
    print("TXEFS can1_bar - After verify_rx_tranceiver reg_val_32 is", reg_val_32)
    print("\n")
    
    print("Reading IR ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR can0_bar - reg_val_32 is", reg_val_32)
    print("\n")     
            
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")    
    
def Test_case_7_Parity_Check_messageram_with_clearing():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #Step 1: Verify Parity enabled/Disabled by default
    print("#Step 1: Verify Parity enabled/Disabled by default")
    print("Reading Paity PAR_CTL_STAT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
    print("Reading PAR_CTL_STAT", reg_val_32)
    print("\n") 
    print("\n")

    #Step 2: Set Error injection enable and injection mode
    print("#Step 2: Set Error injection enable and injection mode")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
    reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
    print("\n") 
    print("\n")     

    
    #Step 3: Set offset and Error injection data mask
    print("#Step 3: Set offset and Error injection data mask")    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00000800)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    print("Reading PAR_EINJ_OFFSET value", reg_val_32)
    print("\n") 
    print("\n") 
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x10000000)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")     

    #Step 4: configure 11 bit filter
    print("#Step 4: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")      
    
    #Step 5: Read one-time error occured
    print("#Step 5: Read one-time error occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
    print("\n") 
    
    #Step 6: Read stored offset value is correct
    print("#Step 6: Read stored offset value is correct")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Reading PAR_ERR_OFFSET to see in which offset error has occured", reg_val_32)
    print("\n")    
 
    #Step 7: Read PERR_OCCURED=1
    print("#Step 7: Read PERR_OCCURED=1 ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED=1", reg_val_32)
    print("\n")   
    
    #Step 8: Read EINJ_EN deasserts    
    print("#Step 8: Read EINJ_EN deasserts")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
    print("\n")

    #Step 9: set EINJ_EN=1 to clear one-time error
    print("#Step 9: set EINJ_EN=1 to clear one-time error")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
    reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
    print("\n") 
    print("\n")     

    #Step 10: Repeat steps 3 and 4
    print("#Step 10: Repeat steps 3 and 4")
    print("Set offset and Error injection data mask")    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00000800)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    print("Reading PAR_EINJ_OFFSET value", reg_val_32)
    print("\n") 
    print("\n") 
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x10000000)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")     

    #Step 11: configure 11 bit filter
    print("#Step 11: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")      
    
    #Step 12: Read one-time error not occured
    print("#Step 12: Read one-time error not occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)#value=0
    print("\n") 
    
    #Step 13: Read stored offset value is stored
    print("#Step 13: Read stored offset value is stored")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Read stored offset value", reg_val_32)
    print("\n")    
 
    #Step 14: Read PERR_OCCURED not occured
    print("#Step 14: Read PERR_OCCURED not occured ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED not occured", reg_val_32)
    print("\n")   
    
    
def Test_case_7_one_time_error_injection():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    print("#By default PAR_EINJ_DATA_MASK- check values of PAR_EINJ_DATA_MASK =0  " )
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset) 
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")
    
    #Step 1: Verify Parity enabled/Disabled by default
    print("#Step 1: Verify Parity enabled/Disabled by default")
    print("Reading Paity PAR_CTL_STAT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
    print("Reading PAR_CTL_STAT", reg_val_32)
    print("\n") 
    print("\n")
    
    #Step 2: configure 11 bit filter
    print("#Step 2: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")     
    
    


    #Step 3: Set Error injection enable and injection mode
    print("#Step 3: Set Error injection enable and injection mode")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
    reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
    print("\n") 
    print("\n")     

    
    #Step 4: Set offset and Error injection data mask
    print("#Step 4: Set offset and Error injection data mask")    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00000800)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    print("Reading PAR_EINJ_OFFSET value", reg_val_32)
    print("\n") 
    print("\n")
    
    '''
    #Step 5: Dont configure PAR_EINJ_DATA_MASK
    print("#Step 5:Dont configure PAR_EINJ_DATA_MASK- check values of PAR_EINJ_DATA_MASK =0  " )
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset) 
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")
    '''
    #Step 5: configure PAR_EINJ_DATA_MASK
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x10000000)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")     
    

    #Step 6: configure 11 bit filter
    print("#Step 6: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")      
    
    #Step 7: Read one-time error occured
    print("#Step 7: Read one-time error occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
    print("\n") 
    
    #Step 8: Read stored offset value is correct
    print("#Step87: Read stored offset value is correct")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Reading PAR_ERR_OFFSET to see in which offset error has occured", reg_val_32)
    print("\n")    
 
    #Step 9: Read PERR_OCCURED=1
    print("#Step 9: Read PERR_OCCURED=1 ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED=1", reg_val_32)
    print("\n") 

    '''
    #Step A: Read IR.BEU
    print("#Step 9: R.BEU ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset) >>2
    print("Read IR.BEU", reg_val_32)
    print("\n")    
    
    #Step B: Read CCCR.INIT
    print("#Step 9: CCCR.INIT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset) >>2
    print("Read CCCR.INIT", reg_val_32)
    print("\n") 
    '''
    #Step 10: Read EINJ_EN deasserts    
    print("#Step 10: Read EINJ_EN deasserts")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
    print("\n")

   

    #Step 11: configure 11 bit filter
    print("#Step 11: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 


    #Step 12: configure 11 bit filter
    print("#Step 12: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 

    #Step 13: configure 11 bit filter
    print("#Step 13: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 

  
    
    #Step 13: Read one-time error not occured
    print("#Step 13: Read one-time error not occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
    print("\n") 
    
    #Step 13: Read stored offset value is stored
    print("#Step 13: Read stored offset value is stored")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Read stored offset value", reg_val_32)
    print("\n")    
 
    #Step 14: Read PERR_OCCURED not occured
    print("#Step 14: Read PERR_OCCURED not occured ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED not occured", reg_val_32)
    print("\n")  

def Test_case_7_continuous_error_injection():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #Step 1: Verify Parity enabled/Disabled by default
    print("#Step 1: Verify Parity enabled/Disabled by default")
    print("Reading Paity PAR_CTL_STAT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
    print("Reading PAR_CTL_STAT", reg_val_32)
    print("\n") 
    print("\n")
    
    #Step 2: configure 11 bit filter
    print("#Step 2: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")     
    
    


    #Step 3: Set Error injection enable and injection mode
    print("#Step 3: Set Error injection enable and injection mode")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
    reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #one-time error
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
    print("\n") 
    print("\n")     

    
    #Step 4: Set offset and Error injection data mask
    print("#Step 4: Set offset and Error injection data mask")    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00000800)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    print("Reading PAR_EINJ_OFFSET value", reg_val_32)
    print("\n") 
    print("\n") 
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")     

    #Step 5: configure 11 bit filter
    print("#Step 5: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n")      
    
    #Step 6: Read one-time error occured
    print("#Step 6: Read one-time error occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
    print("\n") 
    
    #Step 7: Read stored offset value is correct
    print("#Step 7: Read stored offset value is correct")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Reading PAR_ERR_OFFSET to see in which offset error has occured", reg_val_32)
    print("\n")    
 
    #Step 8: Read PERR_OCCURED=1
    print("#Step 8: Read PERR_OCCURED=1 ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED=1", reg_val_32)
    print("\n")   
    
   

    #Step 9: configure 11 bit filter
    print("#Step 9: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 


    #Step 10: configure 11 bit filter
    print("#Step 10: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 

    #Step 11: configure 11 bit filter
    print("#Step 11: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("Reading MsgRAM 11 bit filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
    print("\n") 

  

    #Step 12: Read stored offset value is stored
    print("#Step 12: Read stored offset value is stored")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Read stored offset value", reg_val_32)
    print("\n")    
 
    #Step 13: Read PERR_OCCURED not occured
    print("#Step 13: Read PERR_OCCURED not occured ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED not occured", reg_val_32)
    print("\n")    
 
def Test_case_33_continuous_error_injection_4300():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #Step 1: Verify Parity enabled/Disabled by default
    print("#Step 1: Verify Parity enabled/Disabled by default")
    print("Reading Paity PAR_CTL_STAT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
    print("Reading PAR_CTL_STAT", reg_val_32)
    print("\n") 
    print("\n")
    
    #Step 2: configure 11 bit filter and create TX packet
    print("#Step 2: configure 11 bit filter")
    

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf) 
    for i in range(3):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = i)
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
        print("\n")
        print("\n")
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 20)
        print("\n")
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 20)
        print("\n")
        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 20)
        print("\n")
        print("\n")
        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")       



        #Step 3: Set Error injection enable and injection mode
        print("#Step 3: Set Error injection enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        print("\n") 
        print("\n")     

        
        #Step 4: Set offset and Error injection data mask
        print("#Step 4: Set offset and Error injection data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00004300)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     


        #Step 5: check packet is not received at FIFO 0
        print("#Step 5: check packet is not received at FIFO 0")
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
        CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
        #print("Reading MsgRAM 11 bit filter")
        #CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800), dw_count = 8)
        #print("\n") 
        txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)    
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
        print("\n")
        print("\n")
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 20)
        print("\n")
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 20)
        print("\n")
        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 20)
        print("\n")
          
        '''
        #Step 6: Read one-time error occured
        print("#Step 6: Read one-time error occured")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n") 
        '''
        #Step 7: Read stored offset value is correct
        print("#Step 7: Read stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Reading PAR_ERR_OFFSET to see in which offset error has occured", reg_val_32)
        print("\n")    
     
        #Step 8: Read PERR_OCCURED=1
        print("#Step 8: Read PERR_OCCURED=1 ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED=1", reg_val_32)
        print("\n")   
        
        #Step 9: Read EINJ_EN deasserts    
        print("#Step 9: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        print("\n")

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")       

def Test_case_33_continuous_error_injection_4308():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #Step 1: Verify Parity enabled/Disabled by default
    print("#Step 1: Verify Parity enabled/Disabled by default")
    print("Reading Paity PAR_CTL_STAT ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
    print("Reading PAR_CTL_STAT", reg_val_32)
    print("\n") 
    print("\n")
    
    #Step 2: configure 11 bit filter and create TX packet
    print("#Step 2: configure 11 bit filter")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 5, txbuf = txbuf)

    for i in range(5):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = i)
     

    for i in range(5): 
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = i)
    print("\n")
    print("\n")
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    print("\n")
    print("Reading CCCR.INIT")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
    print("Reading CCCR.INIT", reg_val_32)
    print("\n")       



    #Step 3: Set Error injection enable and injection mode
    print("#Step 3: Set Error injection enable and injection mode")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
    reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #one-time error
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
    print("\n") 
    print("\n")     

    
    #Step 4: Set offset and Error injection data mask
    print("#Step 4: Set offset and Error injection data mask")    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    reg_val_32 = ((reg_val_32 & 0xFFFF0000) | 0x00004308)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
    print("Reading PAR_EINJ_OFFSET value", reg_val_32)
    print("\n") 
    print("\n") 
    
    
    CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
    print("Read PAR_EINJ_DATA_MASK", reg_val_32)
    print("\n") 
    print("\n")     


    #Step 5: check packet is not received at FIFO 0
    print("#Step 5: check packet is not received at FIFO 0")
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
 
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 5, txbuf = txbuf)

    for i in range(5):
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = i)
     

    for i in range(5): 
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = i)
        
    print("\n")
    print("\n")
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 20)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 20)
    print("\n")
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 20)
    print("\n")
      
    '''
    #Step 6: Read one-time error occured
    print("#Step 6: Read one-time error occured")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
    print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
    print("\n") 
    '''
    #Step 7: Read stored offset value is correct
    print("#Step 7: Read stored offset value is correct")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
    print("Reading PAR_ERR_OFFSET to see in which offset error has occured", reg_val_32)
    print("\n")    
 
    #Step 8: Read PERR_OCCURED=1
    print("#Step 8: Read PERR_OCCURED=1 ")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
    print("Read PERR_OCCURED=1", reg_val_32)
    print("\n")   
    
    #Step 9: Read EINJ_EN deasserts    
    print("#Step 9: Read EINJ_EN deasserts")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
    print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
    print("\n")

    print("Reading CCCR.INIT")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
    print("Reading CCCR.INIT", reg_val_32)
    print("\n")       

def seed0_Test_case_7_CAN0_Continuous_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (1):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
        

        
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #continuous error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000003
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     


        
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
 
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")                  
 
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")   
        
        
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
           
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")         


                    

        

        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)  ):
            print("FAIL:written data and Read data are not different in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
        
def adjacent_check_Test_case_7_CAN0_Continuous_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (1):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
        
        ##==================================Read adjacent offsets===========================================##
        

        ##==================================write adjacent offsets===========================================##
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        ##====================================================================================##
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #continuous error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000003
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n") 
        

        ##=====================Write offset to which parity to be injected======================##
        
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
        ##=======================================================================================##
        
        
        
        ##=============Read adjacent offsets===================================##
        
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")   
        
        
        
      ##=======================================================================================================##   
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''
        
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")         


                    

        

        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)  ):
            print("FAIL:written data and Read data are not different in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##       
        


        
def Test_case_7_CAN0_one_time_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        '''
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffB) | 1)
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_CTL_STAT.offset, reg_val_32)
        CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("PAR_CTL_STAT is", reg_val_32)
        
        '''
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
       

        
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     


        ##==============================Reading Adjacent memories=================================================##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
 
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val")
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val-4", )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val+4")
            print("\n")       
        else:
			print("PASS")                  
        
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")       
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        print("\n")

                    
        print("\n")
        #Compare function
        
        print("\n")
        print("\n")
        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex !=hex(Read_data)):
            print("FAIL:written data and Read data are not same in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex !=hex(Read_data)  ):
            print("FAIL:written data and Read data are not same in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
        
        
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffB) | 1)
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_CTL_STAT.offset, reg_val_32)
        CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("PAR_CTL_STAT is", reg_val_32)
        
        
def Test_case_7_CAN1_one_time_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can1_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (0,2):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        
        print("SEED_ID is",seed_id)
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
        
    
        
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     

  
        
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
 
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val")
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val-4", )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val+4")
            print("\n")       
        else:
			print("PASS")                  
        
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")       
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        ''' 
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")   
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        print("\n")

                    
        print("\n")
        #Compare function
        
        print("\n")
        print("\n")
        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex !=hex(Read_data)):
            print("FAIL:written data and Read data are not same in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex !=hex(Read_data)  ):
            print("FAIL:written data and Read data are not same in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
        
        
def Test_case_7_CAN0_Continuous_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (0,2):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
        

        
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #continuous error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000003
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     


        
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
        
         
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        
        
        ##=============================================================##
        
        
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")                  
 
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")   
        
        
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''   
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")         


                    

        

        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)  ):
            print("FAIL:written data and Read data are not different in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
        
        
        
def Test_case_7_CAN1_Continuous_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can1_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    
    from random import seed
    for i in range (0,2):
        seed_id = i
        seed(seed_id)
        addr_list = range(0x800,0x4781,0x4)
        addr_val = random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        print("\n") 
        print("\n")
        

        
        


        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #continuous error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000003
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#EINJ_OFFSET = 0x800 for error injection enable ,EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00000001)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     


        
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)        
        print("Written data is ", data_hex, "for address", hex(addr_val))
        print("\n") 
 
        if (addr_val != 0x800):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val-4), data_previous)
            print("Written data at previous address is ", data_hex_previous, "for address", hex(addr_val-4))
            print("\n")
        if (addr_val != 0x4780):
            CanDeviceLibrary.WriteMmio(m_bar, (addr_val+4), data_next)
            print("Written data at Next address is ", (data_hex_next), "for address", hex(addr_val+4))
            print("\n")        
        
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next !=hex(Read_data)):
                print("FAIL:written data and Read data are not same during 1st ERR Injection in addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")                  
 
        '''
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different during 1st ERR Injection for addr_val. Written data is", data_hex, "Read data is", hex(Read_data) )
        else:
			print("PASS")
        print("\n")
        
        if (addr_val != 0x800):               
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val-4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val-4))
            if (data_hex_previous ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val-4. Written data is", data_hex_previous, "Read data is", hex(Read_data) )
            print("\n")
        else:
			print("PASS")        
            
        if (addr_val != 0x4780):
            Read_data = CanDeviceLibrary.ReadMmio(m_bar, (addr_val+4))
            print("Read data is ", hex(Read_data), "for address", hex(addr_val+4))        
            if (data_hex_next ==hex(Read_data)):
                print("FAIL:written data and Read data are not different in adjacent addr_val+4. Written data is", data_hex_next, "Read data is", hex(Read_data))
            print("\n")       
        else:
			print("PASS")   
        
        
        
        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''   
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("PASS:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")         


                    

        

        
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)):
            print("FAIL:written data and Read data are not different in 2nd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
       
        ##=============================================== ##
        CanDeviceLibrary.WriteMmio(m_bar, addr_val, data)
        print("Written data is ", (data_hex), "for address", hex(addr_val))        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, addr_val)
        print("Read data is ", hex(Read_data), "for address", hex(addr_val))
        if (data_hex ==hex(Read_data)  ):
            print("FAIL:written data and Read data are not different in 3rd ERR Injection")
        else:
			print("PASS")            
        ##=============================================== ##
        
def Test_case_33_data_pkt_CAN0_one_time_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    TxBufferOffset = random.randint(5, 31)

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 0, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #TODO: create11bitFilter
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #TODO: Push11bitFilter

    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        #TODO check later # addr_list = range(0x4300,0x4781,0x4)
        addr_list = range(0x3B00+(TxBufferOffset*16),0x3B00+(TxBufferOffset*16)+15,0x4)
        addr_val = 0x800 + random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        print("addr_val is",addr_val)
       
        #====================================Read CCCR.INIT============================================ #
    
        print("#Step 1: Verify CCCR.INIT =0")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")
        
         #====================================================================================== #

 
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PARITY_EN!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")
        
       
       ##========================Read IR for 21st bit before=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
      
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x0):
            print("FAIL:Read IR.BEU!=0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   

        
           
        ##===============================================================##  
        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")        
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | (m_bar+addr_val))#Eaddr_val= different offset value, EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00040000)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     
        #====================================================================================== #

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr_val-64, dw_count = 100)
        print("\n")
        
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
        print("\n")        
        

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
         
        ##==============Verify Packets are dropped from 3rd packets after parity ERR_ING==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        ##=============================================================================================##



        # =============================================================================== #
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")    

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        reg_val_32= reg_val_32 & 0x00000001
        print("Reading CCCR.INIT", reg_val_32)
        if (reg_val_32 != 0x1):
            print("FAIL:CCCR.INIT= 1")
                     
        else:
			print("PASS")
        
        
        print("\n")      
##========================Read IR=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
        
        reg_val_32=reg_val_32 >>21
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:Read IR.BEU=1")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
        
##===============================================================##        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = reg_val_32 &0x00000001
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        
        print("\n")
        if (reg_val_32 != 0x0):
            print("FAIL:EINJ_EN= 0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")
        

        #Compare function
        
        print("\n")
        print("\n")

         
           
       #====================================================================================== #
       #====================================================================================== #
 

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr_val-64, dw_count = 100)
        print("\n")
        
        
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
        print("\n")         

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
         
        ##==============Verify Packets are NOT dropped from 3rd packet in one time err inj==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
       
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        '''
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''

def Test_case_33_data_pkt_CAN1_one_time_error_injection_Randamization():
    
    can1_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can1_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    TxBufferOffset = random.randint(5, 31)

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 0, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #TODO: create11bitFilter
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    #TODO: Push11bitFilter

    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        #TODO check later # addr_list = range(0x4300,0x4781,0x4)
        addr_list = range(0x3B00+(TxBufferOffset*16),0x3B00+(TxBufferOffset*16)+15,0x4)
        addr_val = 0x800 + random.choice(addr_list)
        #addr_val = hex(addr_dec).split('x')[-1]
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
       
        #====================================Read CCCR.INIT============================================ #
    
        print("#Step 1: Verify CCCR.INIT =0")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")
        
         #====================================================================================== #

 
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PARITY_EN!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")
        
       
       ##========================Read IR for 21st bit before=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.IR.offset)
      
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x0):
            print("FAIL:Read IR.BEU!=0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   

        
           
        ##===============================================================##  
        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can1.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_CTL_STAT.offset)
        
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")        
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | addr_val)#Eaddr_val= different offset value, EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can1.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can1.PAR_EINJ_DATA_MASK.offset, 0x00040000)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     
        #====================================================================================== #

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr_val-64, dw_count = 100)
        print("\n")
        
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
        print("\n")        
        

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
         
        ##==============Verify Packets are dropped from 3rd packets after parity ERR_ING==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        ##=============================================================================================##



        # =============================================================================== #
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")    

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.CCCR.offset)
        reg_val_32= reg_val_32 & 0x00000001
        print("Reading CCCR.INIT", reg_val_32)
        if (reg_val_32 != 0x1):
            print("FAIL:CCCR.INIT= 1")
                     
        else:
			print("PASS")
        
        
        print("\n")      
##========================Read IR=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.IR.offset)
        
        reg_val_32=reg_val_32 >>21
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:Read IR.BEU=1")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
        
##===============================================================##        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = reg_val_32 &0x00000001
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        
        print("\n")
        if (reg_val_32 != 0x0):
            print("FAIL:EINJ_EN= 0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")
        

        #Compare function
        
        print("\n")
        print("\n")

         
           
       #====================================================================================== #
       #====================================================================================== #
 

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr_val-64, dw_count = 100)
        print("\n")
        
        
        
        print("Reading MsgRAM Tx Event Fifo")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 50)
        print("\n")         

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
         
        ##==============Verify Packets are NOT dropped from 3rd packet in one time err inj==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
       
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        '''
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''

def Test_case_33_data_pkt_CAN0_continuous_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    addr_val=0x4300
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    TxBufferOffset = random.randint(5, 31)

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #TODO: create11bitFilter
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #TODO: Push11bitFilter

    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        #TODO check later # addr_list = range(0x4300,0x4781,0x4)
        #addr_list = range(0x3B00+(TxBufferOffset*16),0x3B00+(TxBufferOffset*16)+15,0x4)
        #addr_val = 0x800 + random.choice(addr_list)
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
       
        #====================================Read CCCR.INIT============================================ #
    
        print("#Step 1: Verify CCCR.INIT =0")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")
        
         #====================================================================================== #

 
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PARITY_EN!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")
        
       
       ##========================Read IR for 21st bit before=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
      
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x0):
            print("FAIL:Read IR.BEU!=0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
		##=====================================Packets are written to TX buffer before ERR_INJ===============================##
        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            addr_val = CanDeviceLibrary.GetTxBufferOffset(m_bar = m_bar, pos = TxBufferOffset)
            print("addr_val is", addr_val)

            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer-before ERR_INJ")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
                
        

        print("Reading MsgRAM RxFiFo0--before ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
               
        ##==============================================================================================##   
        ##===============================================================##  
        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (1<<1)) #continuous error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        if (reg_val_32 != 0x3):
            print("FAIL:PAR_EINJ_CTL_STAT!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")        
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | (m_bar + addr_val))#Eaddr_val= different offset value, EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00040000)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     
        #====================================================================================== #

        ##==================================ERR_INJ to 3rd packet====================================================##
        txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset, txbuf = txbuf) 
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset)
            
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset)

  
       
        print("Reading MsgRAM Tx Buffer-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        

        print("Reading MsgRAM RxFiFo0-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        
        ##======================================================================================##
         
        ##==============Verify Packets are dropped from 3rd packets after parity ERR_ING==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        ##=============================================================================================##



        # =============================================================================== #

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        reg_val_32= reg_val_32 & 0x00000001
        print("Reading CCCR.INIT", reg_val_32)
        if (reg_val_32 != 0x1):
            print("FAIL:CCCR.INIT= 1")
                     
        else:
			print("PASS")
        
        
        print("\n")      
##========================Read IR=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
        
        reg_val_32=reg_val_32 >>21
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:Read IR.BEU=1")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
        
##===============================================================##        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         

         
           
       #====================================================================================== #
       #===============================Packets creating 2nd time to check continuous behaviour======================================================= #
 

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        
        

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        '''
        #==============================================================================# 
        ##==============Verify Packets are NOT dropped from 3rd packet in one time err inj==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
       
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''
        
        
        
def Debug_Test_case_33_data_pkt_CAN0_one_time_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    addr_val=0x4300
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    TxBufferOffset = random.randint(5, 31)

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #TODO: create11bitFilter
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #TODO: Push11bitFilter

    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        #TODO check later # addr_list = range(0x4300,0x4781,0x4)
        #addr_list = range(0x3B00+(TxBufferOffset*16),0x3B00+(TxBufferOffset*16)+15,0x4)
        #addr_val = 0x800 + random.choice(addr_list)
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
       
        #====================================Read CCCR.INIT============================================ #
    
        print("#Step 1: Verify CCCR.INIT =0")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")
        
         #====================================================================================== #

 
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PARITY_EN!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")
        
       
       ##========================Read IR for 21st bit before=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
      
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x0):
            print("FAIL:Read IR.BEU!=0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
		##=====================================Packets are written to TX buffer before ERR_INJ===============================##
        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            addr_val = CanDeviceLibrary.GetTxBufferOffset(m_bar = m_bar, pos = TxBufferOffset)
            print("addr_val is", addr_val)

            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer-before ERR_INJ")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
                
        

        print("Reading MsgRAM RxFiFo0--before ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
               
        ##==============================================================================================##   
        ##===============================================================##  
        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")        
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | (m_bar + addr_val))#Eaddr_val= different offset value, EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0x00040000)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     
        #====================================================================================== #

        ##==================================ERR_INJ to 3rd packet====================================================##
        txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset, txbuf = txbuf) 
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset)
            
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset)

  
       
        print("Reading MsgRAM Tx Buffer-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        

        print("Reading MsgRAM RxFiFo0-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        
        ##======================================================================================##
        ''' 
        ##==============Verify Packets are dropped from 3rd packets after parity ERR_ING==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")       

        print("\n")         
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = reg_val_32 &0x00000001
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        
        print("\n")
        if (reg_val_32 != 0x0):
            print("FAIL:EINJ_EN= 0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")
        

        #Compare function
        
        print("\n")
        print("\n")


        # =============================================================================== #

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        reg_val_32= reg_val_32 & 0x00000001
        print("Reading CCCR.INIT", reg_val_32)
        if (reg_val_32 != 0x1):
            print("FAIL:CCCR.INIT= 1")
                     
        else:
			print("PASS")
        
        
        print("\n")      
##========================Read IR=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
        
        reg_val_32=reg_val_32 >>21
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:Read IR.BEU=1")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
        
##===============================================================##        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         

         
           
       #====================================================================================== #
       #===============================Packets creating 2nd time to check continuous behaviour======================================================= #
 

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        
        

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        '''
        #==============================================================================# 
        ##==============Verify Packets are NOT dropped from 3rd packet in one time err inj==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
       
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''

def mask_18_to_32bits_Test_case_33_data_pkt_CAN0_one_time_error_injection_Randamization():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    addr_val=0x4300
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    TxBufferOffset = random.randint(5, 31)

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    
    #TODO: create11bitFilter
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #TODO: Push11bitFilter

    
    from random import seed
    for i in range (0,1):
        seed_id = i
        seed(seed_id)
        #TODO check later # addr_list = range(0x4300,0x4781,0x4)
        #addr_list = range(0x3B00+(TxBufferOffset*16),0x3B00+(TxBufferOffset*16)+15,0x4)
        #addr_val = 0x800 + random.choice(addr_list)
        data = random.randint(1,65535)
        data_previous = random.randint(1,65535)
        data_next = random.randint(1,65535)
        
        data_hex = '0x{0:08X}'.format(data)
        data_hex_previous = '0x{0:08X}'.format(data_previous)
        data_hex_next = '0x{0:08X}'.format(data_next)       
        
        

        print("SEED_ID is",seed_id)
        
       
        #====================================Read CCCR.INIT============================================ #
    
        print("#Step 1: Verify CCCR.INIT =0")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        print("Reading CCCR.INIT", reg_val_32)
        print("\n")
        
         #====================================================================================== #

 
        
        #Step 1: Verify Parity enabled/Disabled by default
        print("#Step 1: Verify Parity enabled/Disabled by default")
        print("Reading Paity PAR_CTL_STAT ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset)
        print("Reading PAR_CTL_STAT", reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PARITY_EN!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")
        
       
       ##========================Read IR for 21st bit before=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
      
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x0):
            print("FAIL:Read IR.BEU!=0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
		##=====================================Packets are written to TX buffer before ERR_INJ===============================##
        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            addr_val = CanDeviceLibrary.GetTxBufferOffset(m_bar = m_bar, pos = TxBufferOffset)
            print("addr_val is", addr_val)

            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer-before ERR_INJ")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
                
        

        print("Reading MsgRAM RxFiFo0--before ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
               
        ##==============================================================================================##   
        ##===============================================================##  
        #Step 2: Set Error injection enable and injection mode
        print("#Step 2: Set ERR_INJ enable and injection mode")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = ((reg_val_32 & 0xfffffffE) | 1)#EINJ_EN = 1 for error injection enable ,EINJ_EN = 0 for error injection disable
        reg_val_32 = ((reg_val_32 & 0xfffffffD) | (0<<1)) #one-time error
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        
        print("Read PAR_EINJ_CTL_STAT", reg_val_32)#value=0x00000001
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT!= 1")
                     
        else:
			print("PASS")
        print("\n")
        print("\n")       
        print("\n") 
        print("\n")        
        print("\n") 
        print("\n")     

        
        #Step 3: Set offset and Error injection data mask
        print("#Step 3: Set offset and ERR_INJ data mask")    
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        reg_val_32 = ((reg_val_32 & 0xFFFF0000) | (m_bar + addr_val))#Eaddr_val= different offset value, EINJ_EN = 0 for error injection disable
        offset_Value = reg_val_32
        
        
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_OFFSET.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_OFFSET.offset)
        print("Reading PAR_EINJ_OFFSET value", reg_val_32)
        print("\n") 
        print("\n") 
        CanDeviceLibrary.WriteMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset, 0xFFFC0000)
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_DATA_MASK.offset)    
        print("Read PAR_EINJ_DATA_MASK", reg_val_32)
        print("\n") 
        print("\n")     
        #====================================================================================== #

        ##==================================ERR_INJ to 3rd packet====================================================##
        txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset, txbuf = txbuf) 
        CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset)
            
        CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset)

  
       
        print("Reading MsgRAM Tx Buffer-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        

        print("Reading MsgRAM RxFiFo0-After ERR_INJ")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        
        ##======================================================================================##
        ''' 
        ##==============Verify Packets are dropped from 3rd packets after parity ERR_ING==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data != 0):
            print("FAIL: 1st packet after ERR_INJ Offest is not dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''
        #Step 4: Read one-time error occured
        print("#Step 4: Read one-time ERR_OCCURED")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)>>2
        print("Reading Paity PAR_EINJ_CTL_STAT to verify EINJ_ONE_TIME_ERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_EINJ_CTL_STAT.EINJ_ONE_TIME_ERR_OCCURED!= 1")
        else:
			print("PASS")       

        print("\n")         
        #Step 7: Read EINJ_EN deasserts    
        print("#Step 7: Read EINJ_EN deasserts")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_EINJ_CTL_STAT.offset)
        reg_val_32 = reg_val_32 &0x00000001
        print("Reading Parity is deasserted EINJ_EN=0", reg_val_32)
        
        print("\n")
        if (reg_val_32 != 0x0):
            print("FAIL:EINJ_EN= 0")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")
        

        #Compare function
        
        print("\n")
        print("\n")


        # =============================================================================== #

        print("Reading CCCR.INIT")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.CCCR.offset)
        reg_val_32= reg_val_32 & 0x00000001
        print("Reading CCCR.INIT", reg_val_32)
        if (reg_val_32 != 0x1):
            print("FAIL:CCCR.INIT= 1")
                     
        else:
			print("PASS")
        
        
        print("\n")      
##========================Read IR=======================================##

       
        print("#Step 7: Read IR.BEU")

        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
        
        reg_val_32=reg_val_32 >>21
        
        print("IR",reg_val_32)
        
        if (reg_val_32 != 0x1):
            print("FAIL:Read IR.BEU=1")
                     
        else:
			print("PASS")
        print("\n")
                    
        print("\n")   
        
##===============================================================##        
        #Step 5: Check stored offset value is correct
        print("#Step 5: Check stored offset value is correct")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_ERR_OFFSET.offset)
        print("Read PAR_ERR_OFFSET ", reg_val_32)
        print("\n")
        reg_val_32 = reg_val_32 & 0x00003FFF
        
        '''
        if (reg_val_32 != offset_Value):
            print("FAIL: Stored offset value != injected offset value")
        else:
			print("PASS")
        '''  
        #Step 6: Read PERR_OCCURED=1
        print("#Step 6: Read PERR_OCCURED ")
        reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PAR_CTL_STAT.offset) >>2
        print("Read PERR_OCCURED", reg_val_32)
        print("\n")
        if (reg_val_32 != 0x1):
            print("FAIL:PAR_CTL_STAT.PERR_OCCURED!= 1")
                     
        else:
			print("PASS")
        print("\n")
        

        print("\n")         

         
           
       #====================================================================================== #
       #===============================Packets creating 2nd time to check continuous behaviour======================================================= #
 

        for i in range (0,5):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = TxBufferOffset+i-2, txbuf = txbuf) 
            CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = TxBufferOffset+i-2)
            if (i<2): # i<2 packets should be received in RxFIFO and i= 2to4 should be dropped, since Parity error is injected in i=2
                CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = TxBufferOffset+i-2)

  
       
        print("Reading MsgRAM Tx Buffer")
        #addr = (0x800 + 0x3B00) + addr_val
        CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = (0x800 + 0x3B00), dw_count = 500)
        print("\n")
        
        
        

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        '''
        #==============================================================================# 
        ##==============Verify Packets are NOT dropped from 3rd packet in one time err inj==============##
        ##==============Verify at 0x90, 0x0D8,0x120 addresses as 1 packet takes 0x48 size(its based on RX FIFO elements size)==============##
       
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x90))
        
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        


        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0xD8))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        
        Read_data = CanDeviceLibrary.ReadMmio(m_bar, (0x800 + 0x400 + 0x120))
        if (Read_data == 0):
            print("FAIL: Second time ERR_INJ: 1st packet after ERR_INJ Offest is dropped")
        else:
            print("PASS")
        ##=============================================================================================##
        '''
        
        
def CAN0_CAN1_to_Vector():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    '''
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    '''
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    '''
    '''
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
     
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
    
    
def Vector_to_CAN1_CAN0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 1, ssync = 0, sfid2 = 0x5)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x8, ssync = 0, sfid2 = 0x9)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    print("send packet from Vector...")
    time.sleep(30)
    
    '''
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    '''
    '''
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    '''
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    '''

def CAN0_CAN1_Vector_both_as_TX_RX():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0xA)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    print("send packet from Vector...")
    time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    '''
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    '''
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    '''
    '''
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
     
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
def Test_case_24_Vector_to_CAN1_CAN0_Debug():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    

    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 1, ssync = 0, sfid2 = 0x5)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x8, ssync = 0, sfid2 = 0x9)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    '''
    print("send packet from Vector...")
    time.sleep(30)
    '''
    CanDeviceLibrary.vector_to_can_send(fd = 0,nsjw=0,can_bitrate=0, fd_bitrate=0, is_extended=0, ntseg1=0, ntseg2=0, dsjw=0, dtseg1=0, dtseg2=0, brs=0,remote_frame=0, dlc=0  )


    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    
def can_init_can1_to_can0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7FF
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)
    
def can_init_can0_to_can1():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7FF
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
    
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    


    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    #CanDeviceLibrary.Readerror(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)
    
    
def Testcase_23_CAN0_CAN1_to_Acute_For_CAN():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
  
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)  
    
    
    
    
    
    
    
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x17FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x17FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x17FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    
    CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, 0x7)
    CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBAR.offset, 0x7)
    
    
    
    
    
    

    

    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    '''
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    '''
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    '''
    '''
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
     
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
def Testcase_23_CAN0_CAN1_to_Acute_For_CAN_FD():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 32
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
  
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)  
    
    
    
    
    
    
    
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 32, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    
    CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, 0x7)
    CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBAR.offset, 0x7)
    
    
    
    
    
    

    

    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    '''
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    '''
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    '''
    '''
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
     
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    ''' 
    
    
    
def Test_case_20_data_frame_over_remote_frame():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 3, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
   
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 1, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)  
    
    
    
    '''
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    '''
    CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, 0xF)
    
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    

    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
    print("\n")

    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 100)
    print("\n")
    
   
def Test_case_20_data_frame_over_remote_frame_rand():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    
    from random import seed

    for i in range(1,20):    
        seed_id = i
        seed(seed_id)
        print ("seed_id is", seed_id)        
        CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
        CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
        
        CanDeviceLibrary.can_end_communication(m_bar = m_bar)
        CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
        
        
     
        
        
        CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        
        CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
        CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
        CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.can_start_communication(m_bar = m_bar)
        CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


        # Randomize variables    
        num_packets = random.randint(1, 31)
        print("num_packets:",num_packets)
       
        for i in range(1,num_packets):    
            val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7FF)
            CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = i, filt = val)
        '''
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x0, ssync = 0, sfid2 = 0x50)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x0, ssync = 0, sfid2 = 0x50)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x0, ssync = 0, sfid2 = 0x50)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 3, filt = val)
        '''
        prev_canID = 0x1    
        for i in range(0,num_packets): 
            can_id_rand = random.randint(min_can_id, max_can_id)    
            rand_remote_pkt = random.randint(0, 1)
            if (rand_remote_pkt ==1):
                #if (random.randint(0, 1)):
                canID = prev_canID  
                #else:
                #    canID = can_id_rand

            else:
                canID = can_id_rand
            
            txbuf = CanDeviceLibrary.createTxPacket(can_id=canID, rtr = rand_remote_pkt, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = i, txbuf = txbuf)       
            prev_canID = can_id_rand;       
            
      
        
        
        '''
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
        '''
        reg_val_32=0x0
        for i in range(0,num_packets): 
            buffer_element_enable = (0x1 << i) 
            reg_val_32 = (reg_val_32 ) | buffer_element_enable
        CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, reg_val_32)
        print("TXBAR.offset - Number of buffer elements enabled are:", reg_val_32)
        
        '''
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
        print("\n")

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        '''
        
        CanDeviceLibrary.verify_rx_fifo_remote_frame(m_bar= can1_bar, addr = (0x800 + 0x400), num_packets = num_packets)
        
        
def Test_case_16_stuff_concept():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    '''
    

   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 3, filt = val)
    
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 4, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 5, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 6, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x7FF)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 7, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
   
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1F, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x3F, rtr = 1, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7F, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 3)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)  
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x6, rtr = 1, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 4)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 5)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 5, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0xFF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 6)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 6, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FF, rtr = 1, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 7)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 7, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)   
    '''
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
    '''
    CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, 0xFF)
    
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    

    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 150)
    print("\n")

    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 150)
    print("\n")
 
 
def Test_case_16_stuff_concept_rand():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A

    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)- normal packet from 1 to 1E
    max_can_id = 0x1E  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1

    

    
    from random import seed

    for i in range(0,501):  #Number of seeds
        txbuf = []

        can_id_sent_array =[]
        tx_data = []
        #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
        for p in range(0,num_bytes):
            tx_data.append(start_num+p)
                

        seed_id = i
        seed(seed_id)
        print ("seed_id is", seed_id)        
        CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
        CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
        
        CanDeviceLibrary.can_end_communication(m_bar = m_bar)
        CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
        
        
     
        
        
        CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 1, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        
        CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
        CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
        CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.can_start_communication(m_bar = m_bar)
        CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


        # Randomize variables    
        num_packets = random.randint(1, 31)

        print("num_packets:",num_packets)
       
        for i in range(num_packets):    
            val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
            CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = i, filt = val)
        '''    
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 3, filt = val)
        '''
        prev_canID = 0x1    
        for i in range(0,num_packets): 
            xtd=0;
            
            #pcaket_type=0 - Normal data
            #pcaket_type=1 - Remote data    
            #pcaket_type=2 - Normal stuffed data
            #pcaket_type=3 - Remote stuffed data 
            
            packet_type = random.randint(0, 3)  
            
            if (packet_type == 0 or 1):
                can_id_rand = random.randint(0x1, 0x1E) 
                
            if (packet_type == 2 or 3):
                if (xtd == 1):
                    stuff_id_pos = random.randint(0, 23)
                else:
                    stuff_id_pos = random.randint(0, 5)
                    
                can_id_rand =0x1F
                for j in range(0,stuff_id_pos): 
                    can_id_pos = (0x1 << (j+5))
                    can_id_rand = (can_id_rand) | can_id_pos
                    #if (xtd == 0):
                        #can_id_rand = (can_id_rand<<18)
                    
                
                        
            rand_remote_pkt = random.randint(0, 1)
            if (rand_remote_pkt ==1):
                #if (random.randint(0, 1)):
                    canID = prev_canID  
                #else:
                #    canID = can_id_rand

            else:
                canID = can_id_rand
            print("CANID is ", canID)
            can_id_sent_array.append(canID)
            
            txbuf = CanDeviceLibrary.createTxPacket(can_id=canID, rtr = rand_remote_pkt, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = i, txbuf = txbuf)       
            prev_canID = can_id_rand;       
            
      
        
        
        '''
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
        '''
        reg_val=0x00000000
        for k in range(0,num_packets): 
            buffer_element_enable = (0x1 << k) 
            reg_val = (reg_val ) | buffer_element_enable
        CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, reg_val)
        print("TXBAR.offset - buffer elements enabled bits are:", reg_val)
        '''
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 80)
        print("\n")

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 100)
        print("\n")
        '''
        can_id_sent_array.sort()
        print("Sorted CANID array is", can_id_sent_array)
        CanDeviceLibrary.verify_rx_fifo_remote_frame_with_stuff(m_bar= can1_bar, addr = (0x800 + 0x400), num_packets = num_packets, can_id_sent_array=can_id_sent_array,xtd=0)        
        


 
def Test_case_18_txbcr_rand():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A

    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)- normal packet from 1 to 1E
    max_can_id = 0x1E  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1

    

    
    from random import seed

    for i in range(0,1):  #Number of seeds
        txbuf = []

        can_id_sent_array =[]
        tx_data = []
        #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
        for p in range(0,num_bytes):
            tx_data.append(start_num+p)
                

        seed_id = i
        seed(seed_id)
        print ("seed_id is", seed_id)        
        CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
        CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
        
        CanDeviceLibrary.can_end_communication(m_bar = m_bar)
        CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
        
        
     
        
        
        CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 32, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 32, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        
        CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
        CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
        CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.can_start_communication(m_bar = m_bar)
        CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


        # Randomize variables    
        num_packets = 23#random.randint(1, 31)

        print("num_packets:",num_packets)
       
        for i in range(num_packets):    
            val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
            CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = i, filt = val)
        '''    
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 1, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 2, filt = val)
        
        val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
        CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 3, filt = val)
        '''
        prev_canID = 0x1    
        for i in range(0,num_packets): 
            xtd=0;
            
            #pcaket_type=0 - Normal data
            #pcaket_type=1 - Remote data    
            #pcaket_type=2 - Normal stuffed data
            #pcaket_type=3 - Remote stuffed data 
            
            packet_type = random.randint(0, 3)  
            
            if (packet_type == 0 or 1):
                can_id_rand = random.randint(0x1, 0x1E) 
                
            if (packet_type == 2 or 3):
                if (xtd == 1):
                    stuff_id_pos = random.randint(0, 23)
                else:
                    stuff_id_pos = random.randint(0, 5)
                    
                can_id_rand =0x1F
                for j in range(0,stuff_id_pos): 
                    can_id_pos = (0x1 << (j+5))
                    can_id_rand = (can_id_rand) | can_id_pos
                    #if (xtd == 0):
                        #can_id_rand = (can_id_rand<<18)
                    
                
                        
            rand_remote_pkt = random.randint(0, 1)
            if (rand_remote_pkt ==1):
                #if (random.randint(0, 1)):
                    canID = prev_canID  
                #else:
                #    canID = can_id_rand

            else:
                canID = can_id_rand
            print("CANID is ", canID)
            can_id_sent_array.append(canID)
            
            txbuf = CanDeviceLibrary.createTxPacket(can_id=canID, rtr = rand_remote_pkt, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = i)
            CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = i, txbuf = txbuf)       
            prev_canID = can_id_rand;       
            
      
        
        
        '''
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FF, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FE, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 1, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 1)
        
        txbuf = CanDeviceLibrary.createTxPacket(can_id=0x7FD, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 13, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
        CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 2, txbuf = txbuf)
        '''
    
        
        reg_val=0x00000000
        for k in range(0,num_packets): 
            buffer_element_enable = (0x1 << k) 
            reg_val = (reg_val ) | buffer_element_enable
        CanDeviceLibrary.WriteMmio(m_bar, can0.TXBAR.offset, reg_val)
        print("TXBAR.offset - buffer elements enabled bits are:", reg_val)
             
        reg_val=0x00000000
        #for q in range(1,10):
        c = 20 #random.randint(0,3)
        buffer_element_cancelled = (0x1 << c) 
        reg_val = (reg_val ) | buffer_element_cancelled
        CanDeviceLibrary.WriteMmio(m_bar, can0.TXBCR.offset, reg_val)
        print("TXBCR.offset - Cancelled elements bits are:", reg_val)
        reg_val_TXBCR = CanDeviceLibrary.ReadMmio(m_bar, can0.TXBCR.offset)
        reg_val_TXBRP = CanDeviceLibrary.ReadMmio(m_bar, can0.TXBRP.offset)
        print("TXBRP.offset - Cancelled elements bits are:", reg_val_TXBRP)      
               
               
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 600)
        print("\n")

        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 150)
        print("\n")
        can_id_sent_array.sort()
        print("Sorted CANID array is", can_id_sent_array)
        CanDeviceLibrary.verify_rx_fifo_remote_frame_with_stuff(m_bar= can1_bar, addr = (0x800 + 0x400), num_packets = num_packets, can_id_sent_array=can_id_sent_array,xtd=0)        
        
def Testcase_18_TX_cancellation():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    

    
    from random import seed
    num_packets = 32

    for i in range(0,1):  #Number of seeds
        txbuf = []

        tx_data = []
        #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
        for p in range(0,num_bytes):
            tx_data.append(start_num+p)
                

        seed_id = i
        seed(seed_id)        

       
        CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
        CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
        
        CanDeviceLibrary.can_end_communication(m_bar = m_bar)
        CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
        
        
     
        
        
        CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
        lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
        efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
        ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
        anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
        
        
        
        CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
        CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
        CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
        CanDeviceLibrary.can_start_communication(m_bar = m_bar)
        CanDeviceLibrary.can_start_communication(m_bar = can1_bar)
        for j in range(num_packets):    
            val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x1, ssync = 0, sfid2 = 0x7FF)
            CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = j, filt = val)

        for i in range(num_packets):
            txbuf = CanDeviceLibrary.createTxPacket(can_id=i+1, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
            CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = i, txbuf = txbuf)
        #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
        
        import threading
        
        threading.Thread(target=Poll_TXBRP, name="Poll_TXBRP").start()


        CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBAR.offset, 0x0FFFFFFF)
        
       
     
        '''
        reg_val_32=0x0
        reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBCR.offset)
        reg_val_32 = ((reg_val_32 & 0xFFEFFFFF) | (1 << 20))
        CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBCR.offset, reg_val_32)
        reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBCR.offset)
        print("TXBCR", reg_val_32)
        '''   

        
        
        print("Reading MsgRAM Tx Buffer")
        addr = (0x800 + 0x3B00)
        CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 600)
        print("\n")
        
        print("Reading MsgRAM RxFiFo0")
        CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 600)
        print("\n")    
        
        CanDeviceLibrary.verify_rx_fifo_TXBC(m_bar = can1_bar,  addr = (0x800 + 0x400), num_packets = num_packets)
        
     
def Poll_TXBRP_OLD():
    can1_bar = 0x50418000
    PollCount =0

    while True:              
        reg_val_32=0x0
        reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBRP.offset)
        #print("TXBRP:", reg_val_32) 
        if (reg_val_32 !=0):
            print("TXBRP success")
            print("TXBRP is", reg_val_32)            
            CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBCR.offset, reg_val_32)
            reg_val_32=0
            reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBCR.offset)
            print("TXBCR is", reg_val_32)
            break

        PollCount += 1
        if (PollCount >= 1000):  # check max count
            print ("ERROR | Hit Maximum count:30 (IR == BitVector<1>")
            break
        
 
def Poll_TXBRP():
    can1_bar = 0x50418000
    PollCount =0

    while True:              
        #reg_val_32=0x0
        #reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBRP.offset)
        #print("TXBRP:", reg_val_32) 
        #if (reg_val_32 !=0):
        CanDeviceLibrary.WriteMmio(can1_bar, can1.TXBCR.offset, 0xFFFFFFFF)
        #reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.TXBCR.offset)
        
        

        PollCount += 1
        if (PollCount >= 10):  # check max count
            print ("Hit Maximum counts")
            break
                      
    
