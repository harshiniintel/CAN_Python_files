###Author: chia.kian.puan@intel.com  --- VICE LPSS SV
## PLEASE DO NOT EDIT ANY of the function. If u want to do so, please inform me. Thank you.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import sys
import ctypes
import random
import time
import math

import itpii
import pci2
import os
import threading 
itp = itpii.baseaccess()



#import my_lib;reload (my_lib)

import log_file_framework as var_log_fw
#import can_reg; reload(can_reg)

import CanDeviceLibrary as CanDeviceLibrary





var_log_ALL=4
var_log_INFORMATION=3
var_log_DEBUG=2
var_log_ERROR=1
var_log_CRITICAL=0

start_time = 0

#Default Assignment

var_log_level_SET=var_log_ALL
#Faster Execution, Restricted Log Level
#var_log_level_SET=var_log_DEBUG



def log_print(var_log_level=var_log_ALL, var_log_line=''):
    if var_log_level <= var_log_level_SET:
        var_log_fw.write_to_existing_file(var_log_line)

log_print(var_log_INFORMATION,str(sys.argv[0]) + " command line arguments : " + str(sys.argv))

# for current func name, specify 0 or no argument.
# for name of caller of current func, specify 1.
# for name of caller of caller of current func, specify 2. etc.
currentFuncName = lambda n=0: sys._getframe(n + 1).f_code.co_name

DID_LIST = {
   
    'PTL' : {'0':{'DID':0x67B5, 'DEV': 0x1D, 'FUNC':0},'1':{'DID':0x67B6, 'DEV': 0x1D, 'FUNC':1}},
    
    }

global prj 
prj = 'PTL'





global CAN
global can0
global can1


mem_src = 0x1000000
mem_dst = 0x2000000



bus=0x03
device=0x1D
func=0x0
func_can1=0x1



def dump_mem (base, length, size=4):
    # itp.threads[0].memdump(str(base)+'p' , str(length)+'p', size)
    itp.threads[0].memdump(str(base)+'p' , length, size)
    return
    

def readMem(address, size=4):
    value = itp.threads[0].mem((str(address) + 'p'), size)
    return value

def writeMem(address, data, size=4):
    itp.threads[0].mem((str(address) + 'p'), size, data)
    return True


def readCfg(bus,device,func,offset):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    value = itp.threads[0].dport(0xcfc)
    return value

def writeCfg(bus,device,func,offset, data):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    itp.threads[0].dport(0xcfc, data)
    return True


##############function to re-initiate project
def fpga_init(proj=prj,verbose= 0):

    global PROJECT

    found = False
 
    #loop to scan bus and identify where the TSN is located
    for i in range(2,23):
        #open PCI cfg space for TSN.
        if(verbose):
            log_print(var_log_INFORMATION, "Open PCI Cfg for B:D:F = %d,0x%x,0x%x\n" % (i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC']))
            
        pci2.OpenPciCfg(i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
        #pci2.OpenPciCfg(i,DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
        
        didread = pci2.ReadPciCfgBits(0x0,31,16)

        pci2.ClosePciCfg()

        if((didread & 0xffff) == DID_LIST[proj]['0']['DID']):  
            log_print(var_log_INFORMATION, "Detected CAN FPGA for %s with DID = 0x%x\n" %(proj,DID_LIST[proj]['0']['DID']))
            found = True
            dev_bus = i
            break
   
    if(not found):
        log_print(var_log_INFORMATION, "ERROR | Did not manage to find any CAN controller\n")
        return 1
        
    
    
    #print I3C
    global CAN
    global can0
    global can1

  
        

    can0 = can_reg.regs(dev_bus, DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
    can1 = can_reg.regs(dev_bus, DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
    CAN =[can0, can1]
    
    
    log_print(var_log_INFORMATION, "MSG_RAM_SIZE =0x%X" % (can0.MSG_RAM_SIZE.read()))
    #log_print(var_log_INFORMATION, "MAC_Version =0x%X" % (can0.MAC_Version.read()))
    #log_print(var_log_INFORMATION, "CSR =0x%X" % (tsn0.CSR.read()))
    
   

    
        
    
    log_print(var_log_INFORMATION, "SUCCESS | FPGA Initialization complete\n")
    
    return
    

def can_init():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    m_bar = can0_bar
    #m_bar = can0_bar
    #  TODO: where do we set the internal loopback?  Which step?
    #CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c_elements = 64, rxbuff_elements=64, lss=128, lse=64, flssa = 0, flesa = 0, eidm = 0, f0sa = 0, f1sa = 0, rbsa = 0, f0ds = 7, f1ds = 7, rbds = 7, efsa = 0, efs = 32, efwm = 0, tbsa = 0, ndtb = 32, tbqs = 0, tbqm = 0, tbds= 7, fdoe = 0, brse = 0, ntseg2 = 0x20, ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0, anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    #CanDeviceLibrary.start_tx(m_bar = m_bar)
    
    #CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c_elements = 64, rxbuff_elements=64, lss=128, lse=64, flssa = 0, flesa = 0, eidm = 0, f0sa = 0, f1sa = 0, rbsa = 0, f0ds = 7, f1ds = 7, rbds = 7, efsa = 0, efs = 32, efwm = 0, tbsa = 0, ndtb = 32, tbqs = 0, tbqm = 0, tbds= 7, fdoe = 0, brse = 0, ntseg2 = 0x20, ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0, anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    #CanDeviceLibrary.start_tx(m_bar = can0_bar)
    
   
    
    ####### Sequence for 2 CAN
    
    
    n_baudrate = 500
    n_sampling = 80 #baudrate.samplingpoint%
    nbrp = 1
    
    f_baudrate = 500
    f_sampling = 80 #baudrate.samplingpoint%
    fbrp = 1
    
    can_clk = 40 #40MHz
    
    n_tq = 1000/(can_clk/nbrp)
    n_bittime_ns = 1000000/n_baudrate
    n_no_of_tq = n_bittime_ns/n_tq
    ntseg1 = ((n_sampling*n_no_of_tq)/100)-1
    ntseg2 = n_no_of_tq-1-ntseg1
    
    
    
    f_tq = 1000/(can_clk/fbrp)
    f_bittime_ns = 1000000/f_baudrate
    f_no_of_tq = f_bittime_ns/f_tq
    ftseg1 = ((f_sampling*f_no_of_tq)/100)-1
    ftseg2 = f_no_of_tq-1-ftseg1
    
    
    
    '''
    S.No CAN_Clk baudrate Sampling nbrp tq bittime no.of.tq NTSEG1 NTSEG2

    1   40	    250	    70	     1	   25	4000	160	   111	   48
    2	40	    125	    80	     4	   100	8000	80	   63	   16
    3	40	    100	    80	     2	   50	10000	200	   159	   40

    '''
    
    print("n_baudrate=%d, n_sampling=%d, n_tq=%d, n_bittime_ns=%d, n_no.of.tq=%d\n"%(n_baudrate,n_sampling,n_tq,n_bittime_ns,n_no_of_tq))
    print("nbrp=%d, ntseg1=%d,ntseg2=%d\n"%(nbrp,ntseg1,ntseg2))
    
    
    print("f_baudrate=%d, f_sampling=%d, f_tq=%d, f_bittime_ns=%d, f_no.of.tq=%d\n"%(f_baudrate,f_sampling,f_tq,f_bittime_ns,f_no_of_tq))
    print("fbrp=%d, ftseg1=%d,ftseg2=%d\n"%(fbrp,ftseg1,ftseg2))
    #return
    
    
    #HW adds +1 to these values internally, so doing minus1 when passing the computed values
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    '''
    for i in range(0,16):
        dlc=i
        num_bytes=CanDeviceLibrary.getNumBytes(dlc) #9=12B, 10=16B, 11=20B, 12=24B, 13=32B, 14=48B, 15=64B
        num_dword = num_bytes/4
        num_remain = num_bytes%4
        print("dl=%d, num_bytes = %d, num_dword=%d, num_remain=%d"%(dlc, num_bytes,num_dword,num_remain))
    return
    '''
   
    dlc=8
    
    #CanDeviceLibrary.clearRAM(m_bar = can0_bar)
    #CanDeviceLibrary.clearRAM(m_bar = can1_bar)
    CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c_elements = 64, rxbuff_elements=64, lss=128, lse=64, flssa = 0, flesa = 0, eidm = 0x1FFFFFFF, f0sa = 0, f1sa = 0, rbsa = 0, f0ds = 7, f1ds = 7, rbds = 7, efsa = 0, efs = 32, efwm = 0, tbsa = 0, ndtb = 32, tbqs = 0, tbqm = 0, tbds= 7, fdoe = 1, brse = 1, ntseg2 = ntseg2, ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0, anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c_elements = 64, rxbuff_elements=64, lss=128, lse=64, flssa = 0, flesa = 0, eidm = 0x1FFFFFFF, f0sa = 0, f1sa = 0, rbsa = 0, f0ds = 7, f1ds = 7, rbds = 7, efsa = 0, efs = 32, efwm = 0, tbsa = 0, ndtb = 32, tbqs = 0, tbqm = 0, tbds= 7, fdoe = 1, brse = 1, ntseg2 = ntseg2, ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0, anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
  
    #CanDeviceLibrary.read_ram_buffers(m_bar = can0_bar)
    #CanDeviceLibrary.read_ram_buffers(m_bar = can1_bar)
  
    
    CanDeviceLibrary.start_rx(m_bar = can1_bar)
    
    
    #CanDeviceLibrary.start_tx(m_bar = can0_bar,xtd = 1,fdf = 0,brs=0)
    #time.sleep(3)
    CanDeviceLibrary.start_tx(m_bar = can0_bar,xtd = 0,fdf = 1,brs=1,dlc=dlc,start_val=0x22)
    #CanDeviceLibrary.start_tx(m_bar = can0_bar,xtd = 0,fdf = 0,brs=0)
    
    CanDeviceLibrary.read_ram_buffers(m_bar = can0_bar,dlc=dlc)
    CanDeviceLibrary.read_ram_buffers(m_bar = can1_bar,dlc=dlc)
    
   # CanDeviceLibrary.start_tx(m_bar = can0_bar)
   # CanDeviceLibrary.start_tx(m_bar = can0_bar)
   # CanDeviceLibrary.start_tx(m_bar = can0_bar)
    #time.sleep(30)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)
    
    
    #################################
    
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar) 
    
    #CanDeviceLibrary.register_write(m_bar = m_bar)
    
    
    #  TODO: Step 7...  need to implement the last subflow.  The rest is in can_setup()
    #  TODO: Start CAN FD communication
    #  Poll for CAN inactive (CCCR.INIT != 0)
    #  Verify
    
    #log_print(var_log_INFORMATION, "ControllerInit Done")