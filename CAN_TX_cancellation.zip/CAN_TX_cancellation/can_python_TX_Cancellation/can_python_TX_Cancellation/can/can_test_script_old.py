###Author: chia.kian.puan@intel.com  --- VICE LPSS SV
## PLEASE DO NOT EDIT ANY of the function. If u want to do so, please inform me. Thank you.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import sys
import ctypes
import random
import time
import math

import itpii
import pci2
import os
import threading 
itp = itpii.baseaccess()



#import my_lib;reload (my_lib)

import log_file_framework as var_log_fw
import can_reg; reload(can_reg)

import CanDeviceLibrary as CanDeviceLibrary





var_log_ALL=4
var_log_INFORMATION=3
var_log_DEBUG=2
var_log_ERROR=1
var_log_CRITICAL=0

start_time = 0

#Default Assignment

var_log_level_SET=var_log_ALL
#Faster Execution, Restricted Log Level
#var_log_level_SET=var_log_DEBUG



def log_print(var_log_level=var_log_ALL, var_log_line=''):
    if var_log_level <= var_log_level_SET:
        var_log_fw.write_to_existing_file(var_log_line)

log_print(var_log_INFORMATION,str(sys.argv[0]) + " command line arguments : " + str(sys.argv))

# for current func name, specify 0 or no argument.
# for name of caller of current func, specify 1.
# for name of caller of caller of current func, specify 2. etc.
currentFuncName = lambda n=0: sys._getframe(n + 1).f_code.co_name

DID_LIST = {
   
    'PTL' : {'0':{'DID':0x67B5, 'DEV': 0x1D, 'FUNC':0},'1':{'DID':0x67B6, 'DEV': 0x1D, 'FUNC':1}},
    
    }

global prj 
prj = 'PTL'


global CAN
global can0
global can1


mem_src = 0x1000000
mem_dst = 0x2000000



bus=0x03
device=0x1D
func=0x0
func_can1=0x1



def dump_mem (base, length, size=4):
    # itp.threads[0].memdump(str(base)+'p' , str(length)+'p', size)
    itp.threads[0].memdump(str(base)+'p' , length, size)
    return
    

def readMem(address, size=4):
    value = itp.threads[0].mem((str(address) + 'p'), size)
    return value

def writeMem(address, data, size=4):
    itp.threads[0].mem((str(address) + 'p'), size, data)
    return True


def readCfg(bus,device,func,offset):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    value = itp.threads[0].dport(0xcfc)
    return value

def writeCfg(bus,device,func,offset, data):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    itp.threads[0].dport(0xcfc, data)
    return True


##############function to re-initiate project
def fpga_init(proj=prj,verbose= 0):

    global PROJECT

    found = False
 
    #loop to scan bus and identify where the TSN is located
    for i in range(2,23):
        #open PCI cfg space for TSN.
        if(verbose):
            log_print(var_log_INFORMATION, "Open PCI Cfg for B:D:F = %d,0x%x,0x%x\n" % (i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC']))
            
        pci2.OpenPciCfg(i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
        #pci2.OpenPciCfg(i,DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
        
        didread = pci2.ReadPciCfgBits(0x0,31,16)

        pci2.ClosePciCfg()

        if((didread & 0xffff) == DID_LIST[proj]['0']['DID']):  
            log_print(var_log_INFORMATION, "Detected CAN FPGA for %s with DID = 0x%x on bus number = 0x%x\n" %(proj,DID_LIST[proj]['0']['DID'],i))
            found = True
            dev_bus = i
            break
   
    if(not found):
        log_print(var_log_INFORMATION, "ERROR | Did not manage to find any CAN controller\n")
        return 1
        
    
    
    #print I3C
    global CAN
    global can0
    global can1

  
        

    can0 = can_reg.regs(dev_bus, DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
    can1 = can_reg.regs(dev_bus, DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
    CAN =[can0, can1]
    
    
    log_print(var_log_INFORMATION, "MSG_RAM_SIZE =0x%X" % (can0.MSG_RAM_SIZE.read()))
    #log_print(var_log_INFORMATION, "MAC_Version =0x%X" % (can0.MAC_Version.read()))
    #log_print(var_log_INFORMATION, "CSR =0x%X" % (tsn0.CSR.read()))
    
   

    
        
    
    log_print(var_log_INFORMATION, "SUCCESS | FPGA Initialization complete\n")
    
    return


def can_init():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 1, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = 1, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)

def can_init_old():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)

    #single Packet
    
    print("First packet")
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFE0000, esync = 0x0, efid2 = 0x1FFF0000)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFE0064, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0) 
    
    
    
    print("second packet")
    
   
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFF8000, esync = 0x0, efid2 = 0x1FFFC000)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFF8050, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1) 
    
    
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 200)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 140)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 140)
    print("\n")
    
    
    
def can_init_extd_filter():
    
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    '''
    print("this is my first sequence")
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x01, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x01, ssync = 0, sfid2 = 0x0)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 7, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    '''
    print("this is my second sequence")
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1fffffff, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    '''
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    '''
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=15555555, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)

    #val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x3d, ssync = 0, sfid2 = 0x0)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x02, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 2, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 20)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 8)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
def can_init_old():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
  
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #eidm=0x1FFFFFFF for SFT= 0,1 2 and eidm=0 for SFT= 3
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)

    #single Packet
    
    """
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFF, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0) 
    
    """
    
    # Multiple packet
    """
   
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
   """
   
    #RX buffer
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x07, efid1 = 0x1, esync = 0x0, efid2 = 0)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFF, esync = 0x0, efid2 = 0x1FFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 1, filt = val)
    
    # val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x01, efid1 = 0x1FFFFFF, esync = 0x0, efid2 = 0x1FFFFFFF)
    # CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 2, filt = val)
    
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    
    # txbuf = CanDeviceLibrary.createTxPacket(can_id=0x1FFFFFFE, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 2)
    # CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)
    # CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 2)
    
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x07, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 1)
    # CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 0x01, pkt_cnt = 1, txbuf = txbuf , pos = 2)
    
    
    print("Reading MsgRAM Extended filter data")
    addr = (0x800 + 0x200)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 100)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 200)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 40)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 140)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 140)
    print("\n")
    
    
    CanDeviceLibrary.ReadFilterPriority(m_bar = m_bar)


    
    print("Reading MsgRAM Rx Filter")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x200), dw_count = 4)
    print("\n")
    
    



    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
def can_init_extd_filter():
    
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec = 0
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    '''
    print("this is my first sequence")
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=0x01, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x01, ssync = 0, sfid2 = 0x0)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    #CanDeviceLibrary.pushTxPacket(m_bar = m_bar, pos = 0, pkt_num = 1, can_id = 0x5A5, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, data0 = 0x04030201, data1 = 0x08070605)
    #CanDeviceLibrary.createTxPacket(dw_num = 0, can_id = 0, rtr = 0, xtd = 0, esi = 0, mm = 0, dlc = 0, brs = 0, fdf = 0, tsce = 0, efc = 0, txbuf = [], tx_data = [])
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=0x114, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data , pos = 1)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 1)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = 7, pkt_cnt = 0, txbuf = txbuf)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 7, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    '''
    print("this is my second sequence")
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    #CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    #CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1fffffff, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 3, rbds = 3, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    '''
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
    ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    '''
    CanDeviceLibrary.retransmission_control(m_bar = m_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = m_bar, internal_loopback  = 1 , loopback_enable  = 1)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=15555555, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 6, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)

    #val = CanDeviceLibrary.create11bitFilter(sft = 1, sfec = 7, sfid1 = 0x3d, ssync = 0, sfid2 = 0x0)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = 0x02, efid1 = 0x1, esync = 0x0, efid2 = 0x1FFFFFFF)
    CanDeviceLibrary.push29BitFilter(m_bar = m_bar, pos = 0, filt = val)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = 2, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x2800), dw_count = 20)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 8)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    
def can_init_can1_to_can0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    CanDeviceLibrary.verify_rx(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf , pos = 0)
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
def Vector_to_CAN0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 31
    ntseg2 = 8
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x20)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    print("send packet from Vector...")
    time.sleep(30)
    
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= m_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''

def Vector_to_CAN1():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    print("send packet from Vector...")
    time.sleep(30)
    
    #txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    #CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    #CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
def Vector_to_CAN1_CAN0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 1, ssync = 0, sfid2 = 0x2)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x3, ssync = 0, sfid2 = 0x4)
    CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR values of CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR values of CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
    
def CAN0_CAN1_to_Vector():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x05
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 10
    ntseg2 = 10
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
 
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)

    print("ECR value at CAN0")
     
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    print("ECR value at CAN1")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
def No_Receiver():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 127
    ntseg2 = 32
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x50)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0x60, ssync = 0, sfid2 = 0x80)
    #CanDeviceLibrary.push11BitFilter(m_bar = m_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    #CanDeviceLibrary.verify_rx_tranceiver(m_bar = m_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("CAN0 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 4)
    print("\n")
    
    
    print("CAN1 Reading MsgRAM 11bit Filter Buffer")
    addr = (0x800)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 80)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x640), dw_count = 80)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)


    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    
def can_init_can0_to_can1():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 16
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7ff;
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    #filt = 0
    val = 0
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)


    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can1.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 10, brs = 1, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.PSR.offset)
    print("PSR reg_val_32 is :", reg_val_32)
    psr=(reg_val_32 & 0x00000007)
    print("LEC  is :", psr)


    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    reg_val_32 = CanDeviceLibrary.ReadMmio(can1_bar, can1.ECR.offset)
    print("ECR reg_val_32 is :", reg_val_32)
    TEC=(reg_val_32 & 0x000000FF)
    print("TEC  is :", TEC)
    
    REC=(reg_val_32 & 0x0000FF00)>>8
    print("REC  is :", REC)
    
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
    
def Test_Case_14():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 16
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    efec = 2
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7;
    sfid1 = 0
    efid1 = 0
    ssync = 0
    sfid2 = 0
    efid2 = 0
    #filt = 0
    val = 0
    
    
    
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = efec, efid1 = 0, esync = 0x0, efid2 = 0x1FFF0000)
    CanDeviceLibrary.push29BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")
    

    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''   
    
    
    
    
def Test_Case_21():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 16
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    efec = 2
    #min_can_id = 0x001  # Minimum possible value (1 in decimal)
    #max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    #can_id = random.randint(min_can_id, max_can_id)
    can_id = 0x7;
    sfid1 = 0
    efid1 = 0
    ssync = 0
    sfid2 = 0
    efid2 = 0
    #filt = 0
    val = 0
    
    
    
    
    #500kbps
    nbrp = 1
    ntseg1 = 63
    ntseg2 = 16
    
    #1000kbps
    fbrp = 1
    ftseg1 = 31
    ftseg2 = 8
    
    
    
    nbrp = nbrp-1
    ntseg1 = ntseg1-1
    ntseg2 = ntseg2-1
    
    fbrp = fbrp-1
    ftseg1 = ftseg1-1
    ftseg2 = ftseg2-1
    
    
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    
    
    
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0x1FFFFFFF, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 3, efwm = 2, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 1, brse = 0, ntseg2 = ntseg2, 
    ntseg1 = ntseg1, nbrp = nbrp, nsjw = 0, fsjw = 0, ftseg2 = ftseg2, ftseg1 = ftseg1, fbrp = fbrp, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    #val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    #CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    val = CanDeviceLibrary.create29bitFilter(eft = 0x0, efec = efec, efid1 = 0, esync = 0x0, efid2 = 0x1FFF0000)
    CanDeviceLibrary.push29BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    
    #print("send packet from Vector...")
    #time.sleep(30)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=1, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 0, txbuf = txbuf)
    
    txbuf = CanDeviceLibrary.createTxPacket(can_id=2, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 1, txbuf = txbuf)

    txbuf = CanDeviceLibrary.createTxPacket(can_id=3, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 2, txbuf = txbuf)

    txbuf = CanDeviceLibrary.createTxPacket(can_id=4, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 3, txbuf = txbuf)

    txbuf = CanDeviceLibrary.createTxPacket(can_id=5, rtr = 0, xtd = 1, esi = 0, mm = 0x1, dlc = 10, brs = 0, fdf = 1, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = m_bar, pos = 4, txbuf = txbuf)
    
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = m_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf,pos = 0)
    

    print("Reading IR TxEventFIFO TEFL")
    reg_val_32 = CanDeviceLibrary.ReadMmio(m_bar, can0.IR.offset)
    print("IR TxEventFIFO : reg_val_32 is", reg_val_32)
    print("\n")     

    

    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 10)
    print("\n")  
 