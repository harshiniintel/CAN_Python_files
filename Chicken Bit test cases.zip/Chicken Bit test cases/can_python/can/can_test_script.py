###Author: chia.kian.puan@intel.com  --- VICE LPSS SV
## PLEASE DO NOT EDIT ANY of the function. If u want to do so, please inform me. Thank you.
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import sys
import ctypes
import random
import time
import math

import itpii
import pci2
import os
import threading 
itp = itpii.baseaccess()



#import my_lib;reload (my_lib)

import log_file_framework as var_log_fw
import can_reg; reload(can_reg)

import CanDeviceLibrary as CanDeviceLibrary





var_log_ALL=4
var_log_INFORMATION=3
var_log_DEBUG=2
var_log_ERROR=1
var_log_CRITICAL=0

start_time = 0

#Default Assignment

var_log_level_SET=var_log_ALL
#Faster Execution, Restricted Log Level
#var_log_level_SET=var_log_DEBUG



def log_print(var_log_level=var_log_ALL, var_log_line=''):
    if var_log_level <= var_log_level_SET:
        var_log_fw.write_to_existing_file(var_log_line)

log_print(var_log_INFORMATION,str(sys.argv[0]) + " command line arguments : " + str(sys.argv))

# for current func name, specify 0 or no argument.
# for name of caller of current func, specify 1.
# for name of caller of caller of current func, specify 2. etc.
currentFuncName = lambda n=0: sys._getframe(n + 1).f_code.co_name

DID_LIST = {
   
    'PTL' : {'0':{'DID':0x67B5, 'DEV': 0x1D, 'FUNC':0},'1':{'DID':0x67B6, 'DEV': 0x1D, 'FUNC':1}},
    
    }

global prj 
prj = 'PTL'


global CAN
global can0
global can1


mem_src = 0x1000000
mem_dst = 0x2000000



bus=0x0A
device=0x1D
func=0x0
func_can1=0x1



def dump_mem (base, length, size=4):
    # itp.threads[0].memdump(str(base)+'p' , str(length)+'p', size)
    itp.threads[0].memdump(str(base)+'p' , length, size)
    return
    

def readMem(address, size=4):
    value = itp.threads[0].mem((str(address) + 'p'), size)
    return value

def writeMem(address, data, size=4):
    itp.threads[0].mem((str(address) + 'p'), size, data)
    return True


def readCfg(bus,device,func,offset):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    value = itp.threads[0].dport(0xcfc)
    return value

def writeCfg(bus,device,func,offset, data):
    arg = ((0x80000000) | (bus << 16) | (device << 11) | (func << 8) | (offset))
    itp.threads[0].dport(0xcf8, arg)
    itp.threads[0].dport(0xcfc, data)
    return True


##############function to re-initiate project
def fpga_init(proj=prj,verbose= 0):

    global PROJECT

    found = False
 
    #loop to scan bus and identify where the TSN is located
    for i in range(2,23):
        #open PCI cfg space for TSN.
        if(verbose):
            log_print(var_log_INFORMATION, "Open PCI Cfg for B:D:F = %d,0x%x,0x%x\n" % (i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC']))
            
        pci2.OpenPciCfg(i,DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
        #pci2.OpenPciCfg(i,DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
        
        didread = pci2.ReadPciCfgBits(0x0,31,16)

        pci2.ClosePciCfg()

        if((didread & 0xffff) == DID_LIST[proj]['0']['DID']):  
            log_print(var_log_INFORMATION, "Detected CAN FPGA for %s with DID = 0x%x on bus number = 0x%x\n" %(proj,DID_LIST[proj]['0']['DID'],i))
            found = True
            dev_bus = i
            break
   
    if(not found):
        log_print(var_log_INFORMATION, "ERROR | Did not manage to find any CAN controller\n")
        return 1
        
    
    
    #print I3C
    global CAN
    global can0
    global can1

  
        

    can0 = can_reg.regs(dev_bus, DID_LIST[proj]['0']['DEV'],DID_LIST[proj]['0']['FUNC'])
    can1 = can_reg.regs(dev_bus, DID_LIST[proj]['1']['DEV'],DID_LIST[proj]['1']['FUNC'])
    CAN =[can0, can1]
    
    
    log_print(var_log_INFORMATION, "MSG_RAM_SIZE =0x%X" % (can0.MSG_RAM_SIZE.read()))
    #log_print(var_log_INFORMATION, "MAC_Version =0x%X" % (can0.MAC_Version.read()))
    #log_print(var_log_INFORMATION, "CSR =0x%X" % (tsn0.CSR.read()))
    
   

    
        
    
    log_print(var_log_INFORMATION, "SUCCESS | FPGA Initialization complete\n")
    
    return


def can_init_can1_to_can0():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    #sfec_values = [1, 2]

    # Randomly choose a value for sfec
    #sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = 0x1, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can0_bar, sfec = 0x1, pkt_cnt = 1, txbuf = txbuf)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    #CanDeviceLibrary.PollIR(m_bar= m_bar,IR_bit_pos=0)
	

	
	
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)
    
def can_init_can0_to_can1():
    
    can0_bar = 0x50410000
    can1_bar = 0x50418000
    
    num_bytes = 8
    start_num = 0x1A
    tx_data = []
    #tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
    for i in range(0,num_bytes):
        tx_data.append(start_num+i)
        
    #tx_data = [0x01, 0x02, 0x03, 0x04,0x05, 0x06, 0x07, 0x08]
    #0x03468<<4 
    #0x04030201
    #0x08070605
    txbuf = []
    m_bar = can0_bar
    sft = 0
    sfec_values = [1, 2]

    # Randomly choose a value for sfec
    sfec = random.choice(sfec_values)
    min_can_id = 0x001  # Minimum possible value (1 in decimal)
    max_can_id = 0x7FF  # Maximum possible value (2047 in decimal)

    # Generate a random CAN ID within the range
    can_id = random.randint(min_can_id, max_can_id)
    sfid1 = 0
    ssync = 0
    sfid2 = 0
    filt = 0
    val = 0
   
    CanDeviceLibrary.clearRAM_control(m_bar = m_bar, clearRAM_enable = 1)
    CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
    
    CanDeviceLibrary.can_end_communication(m_bar = m_bar)
    CanDeviceLibrary.can_end_communication(m_bar = can1_bar)
    
    CanDeviceLibrary.can_setup(m_bar = m_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    
    CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
    lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
    efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x8, 
    ntseg1 = 0x1f, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
    anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
    CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
    CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
    CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
    CanDeviceLibrary.can_start_communication(m_bar = m_bar)
    CanDeviceLibrary.can_start_communication(m_bar = can1_bar)

    val = CanDeviceLibrary.create11bitFilter(sft = 0, sfec = sfec, sfid1 = 0, ssync = 0, sfid2 = 0x7ff)
    CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)
    txbuf = CanDeviceLibrary.createTxPacket(can_id=can_id, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
    CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
    CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
    CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = sfec, pkt_cnt = 1, txbuf = txbuf)
    
    
    print("Reading MsgRAM Tx Buffer")
    addr = (0x800 + 0x3B00)
    CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Tx Event Fifo")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x3A00), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM Rx Buffer")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x2800), dw_count = 4)
    print("\n")
    
    print("Reading MsgRAM RxFiFo0")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x400), dw_count = 8)
    print("\n")
    
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= can1_bar, addr = (0x800 + 0x640), dw_count = 4)
    print("\n")
    
    '''
    print("Reading MsgRAM Rx Fifo1")
    CanDeviceLibrary.ReadRAM(m_bar= m_bar, addr = (0x800 + 0x800), dw_count = 4)
    print("\n")
    '''
        
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = m_bar)
    
    #CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)
	
	
def test8_pm_d0_d3_state():
    
	'''
	a) CAN-0 in S0 state, 
	b) Run traffic from CAN 0 ---> CAN1
	c) Make CAN-0 into D3 state ( IOSF2AXI Bridge PMCS register bit [1:0] =0x3)
	d) Access  to CAN-0 , IOSF2AXI Memory and CAN  registers Write/Read test. Read response will be  0x0
	e) Send traffic from CAN-1 to CAN-0, CAN-0 should not send any Upstream Interrupt to Host.
	f) Come out of D3 state, expect CAN-0 send upstream interrupt to Host.
	'''
	can0_bar = 0x50410000
	can1_bar = 0x50418000
	num_bytes = 8
	start_num = 0x1A
	tx_data = []
	#tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
	for i in range(0,num_bytes):
		tx_data.append(start_num+i)
		
	txbuf = []
	m_bar = can0_bar


	#CanDeviceLibrary.can_pm_S0_state(m_bar = can0_bar)
	CanDeviceLibrary.writeCfg(0x84,0x0,bus,device,func)
	CanDeviceLibrary.writeCfg(0x84,0x0,bus,device,func_can1)
	CanDeviceLibrary.readCfg(0x84,bus,device,func)
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)


	#can-1 setup
	CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
	CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

	CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)


	CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


	#create filter for can 1 
	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)

	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 1, filt = val)

	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x07, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)

	CanDeviceLibrary.writeCfg(0x84,0x3,bus,device,func)
	#CanDeviceLibrary.writeCfg(0x84,0x3,bus,device,func_can1)
	
	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x08, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	#receive fifo check can0 Interrupts 
	CanDeviceLibrary.readIrValue(m_bar = can0_bar)
	
	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	
	CanDeviceLibrary.readIrValue(m_bar = can1_bar)
	
	CanDeviceLibrary.writeCfg(0x84,0x0,bus,device,func)
	CanDeviceLibrary.writeCfg(0x84,0x0,bus,device,func_can1)
	
	print("PMCS is cleared send data from can0 to can1 and vice verse")
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	
	
def test12_pm_multiple_restart_forcepok():
    
	'''
	a) Send traffic from CAN0 ->CAN1. 
    b) Stop the CAN IP clk by writing to CCCR.CSR bit to 1 and poll for CSA bit
    c) Save the PCI config space using cfg read and write
    d) From UHFI mail box, send ResetPrep message to CAN with Source ID as PMClite (0x70)
    e) Wait for Reset Prep Ack from CAN (PMClite will handle this, no action from Host)
    f) send ForcePowergate POK message to CAN (PMClite will handle this, no action from Host)
    g) Monitor can_ss_sb_pok,prim_pok signals de-assert ( read IOSGTG BAR1+0x8088 register bits )
    h) PMClite will assert can_ss_sb/prim_rst_b ( identify capture or read IOSFTG BAR1+ <offset> ) 
    i) Write into IOSFTG BAR1+0x8054 to exit power down state
    j) Write back the PCI config space
    k) Now we can write/read CAN registers to do Init
	'''
	can0_bar = 0x50410000
	can1_bar = 0x50418000
	num_bytes = 8
	start_num = 0x1A
	tx_data = []
	#tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
	for i in range(0,num_bytes):
		tx_data.append(start_num+i)
		
	txbuf = []
	m_bar = can0_bar
	
	CanDeviceLibrary.chicken_bit_enable(bus,device,func,0xb0,0x2)


	
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)


	#can-1 setup
	CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
	CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

	CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)


	CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


	#create filter for can 1 
	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)

	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)

	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x07, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	#CanDeviceLibrary.readIrValue(m_bar = can1_bar)
	
	#create packet and send form can 1
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x08, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	#receive fifo check can0 Interrupts 
	#CanDeviceLibrary.readIrValue(m_bar = can0_bar)
	
	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 1, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 1)
	'''
	CanDeviceLibrary.readIrValue(m_bar = can1_bar)
	print("Reading MsgRAM Tx Buffer before reset prep")
	addr = (0x800 + 0x3B00)
	CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 25)
	print("\n")
	'''
	#CanDeviceLibrary.can_pm_reset_prep(m_bar = can0_bar)
	#CanDeviceLibrary.can_exit_power_down(m_bar = can0_bar)
	CanDeviceLibrary.can_forcePwrGatePOK(m_bar=can0_bar)
	CanDeviceLibrary.can_exit_power_down(m_bar = can0_bar)
	#CanDeviceLibrary.can_exit_clock_stop(m_bar = can0_bar)
	#write cfg data for can 0
	CanDeviceLibrary.writePciConfigSpace(bus, device, func)
	CanDeviceLibrary.printPciConfigSpace(bus, device, func)
	'''
	#initialize can 0 controller
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)
	'''
	
	CanDeviceLibrary.MsgRAMTest(m_bar = can0_bar)

	'''
	print("Reading MsgRAM Tx Buffer after reset prep")
	addr = (0x800 + 0x3B00)
	CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 15)
	print("\n")
	'''
	#CanDeviceLibrary.can_forcePwrGatePOK(m_bar=can0_bar)
	
	#CanDeviceLibrary.can_exit_power_down(m_bar = can0_bar)
	
	#write cfg data for can 0
	#CanDeviceLibrary.writePciConfigSpace(bus, device, func)
	#CanDeviceLibrary.printPciConfigSpace(bus, device, func)
	
	#create packet and send form can 0
	'''
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	'''
	'''
	
	# Example usage for bus 0, device 0, function 0, BAR0
	can0_bar = CanDeviceLibrary.findBAR(bus, device, func, 0x10)
	CanDeviceLibrary.findBAR(bus, device, func_can1, 0x10)
	'''
	'''
	print("Reading MsgRAM Tx Buffer after exit of reset prep")
	addr = (0x800 + 0x3B00)
	CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 25)
	print("\n")
	'''
	
	'''
	print("PMCS is cleared send data from can0 to can1 and vice verse")
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x2, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x3, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	'''
	
def test12_pm_multiple_restart_resetprep():
    
	'''
	a) Send traffic from CAN0 ->CAN1. 
    b) Stop the CAN IP clk by writing to CCCR.CSR bit to 1 and poll for CSA bit
    c) Save the PCI config space using cfg read and write
    d) From UHFI mail box, send ResetPrep message to CAN with Source ID as PMClite (0x70)
    e) Wait for Reset Prep Ack from CAN (PMClite will handle this, no action from Host)
    f) send ForcePowergate POK message to CAN (PMClite will handle this, no action from Host)
    g) Monitor can_ss_sb_pok,prim_pok signals de-assert ( read IOSGTG BAR1+0x8088 register bits )
    h) PMClite will assert can_ss_sb/prim_rst_b ( identify capture or read IOSFTG BAR1+ <offset> ) 
    i) Write into IOSFTG BAR1+0x8054 to exit power down state
    j) Write back the PCI config space
    k) Now we can write/read CAN registers to do Init
	'''
	can0_bar = 0x50410000
	can1_bar = 0x50418000
	num_bytes = 8
	start_num = 0x1A
	tx_data = []
	#tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
	for i in range(0,num_bytes):
		tx_data.append(start_num+i)
		
	txbuf = []
	m_bar = can0_bar
	
	CanDeviceLibrary.chicken_bit_enable(bus,device,func,0xb0,0x2)

	
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)


	#can-1 setup
	CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
	CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

	CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)


	CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


	#create filter for can 1 
	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)

	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)

	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x07, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	#CanDeviceLibrary.readIrValue(m_bar = can1_bar)
	
	#create packet and send form can 1
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x08, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	#receive fifo check can0 Interrupts 
	#CanDeviceLibrary.readIrValue(m_bar = can0_bar)
	
	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 1, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 1)

	#put the clock in resetprep state
	CanDeviceLibrary.can_pm_reset_prep(m_bar = can0_bar)
	#CanDeviceLibrary.can_exit_power_down(m_bar = can0_bar)
	CanDeviceLibrary.can_exit_clock_stop(m_bar = can0_bar)
	
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)
	

	#create packet and send form can 0
	
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = 0x1, pkt_cnt = 1, txbuf = txbuf)
	
	
	print("Reading MsgRAM Tx Buffer after exit of reset prep")
	addr = (0x800 + 0x3B00)
	CanDeviceLibrary.ReadRAM(m_bar= can0_bar,addr = addr, dw_count = 50)
	print("\n")
	
	

def test12_pm_multiple_restart_resetprep_forcepok():
    
	'''
	a) Send traffic from CAN0 ->CAN1. 
    b) Stop the CAN IP clk by writing to CCCR.CSR bit to 1 and poll for CSA bit
    c) Save the PCI config space using cfg read and write
    d) From UHFI mail box, send ResetPrep message to CAN with Source ID as PMClite (0x70)
    e) Wait for Reset Prep Ack from CAN (PMClite will handle this, no action from Host)
    f) send ForcePowergate POK message to CAN (PMClite will handle this, no action from Host)
    g) Monitor can_ss_sb_pok,prim_pok signals de-assert ( read IOSGTG BAR1+0x8088 register bits )
    h) PMClite will assert can_ss_sb/prim_rst_b ( identify capture or read IOSFTG BAR1+ <offset> ) 
    i) Write into IOSFTG BAR1+0x8054 to exit power down state
    j) Write back the PCI config space
    k) Now we can write/read CAN registers to do Init
	'''
	can0_bar = 0x50410000
	can1_bar = 0x50418000
	num_bytes = 8
	#start_num = 0x1A
	
	# Define the range
	start_num = 0x01
	end_num = 0xFF

	# Generate a random number in the specified range
	random_hex = random.randint(start_num, end_num)

	# Convert the number to hexadecimal format
	random_hex_str = hex(random_hex)

	tx_data = []
	#tx_data = [0x0437456, 0x03468, 0x02236, 0x0146,0x0845, 0x07576, 0x06367, 0x0534]
	for i in range(0,num_bytes):
		#tx_data.append(start_num+i)
		tx_data.append(random_hex+i)
		
	txbuf = []
	m_bar = can0_bar
	
	CanDeviceLibrary.chicken_bit_enable(bus,device,func,0xb0,0x2)
	CanDeviceLibrary.chicken_bit_enable(bus,device,func_can1,0xb0,0x2)

	
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)


	#can-1 setup
	CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
	CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

	CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)


	CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


	#create filter for can 1 
	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)

	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)

	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x07, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	#CanDeviceLibrary.readIrValue(m_bar = can1_bar)
	
	#create packet and send form can 1
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x08, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can1_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can1_bar, pos = 0)
	#receive fifo check can0 Interrupts 
	#CanDeviceLibrary.readIrValue(m_bar = can0_bar)
	
	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0xa, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 1)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 1, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 1)

	#put the clock in resetprep state
	CanDeviceLibrary.can_pm_reset_prep(m_bar = can0_bar)
	CanDeviceLibrary.can_forcePwrGatePOK(m_bar=can0_bar)
	CanDeviceLibrary.can_exit_power_down(m_bar = can0_bar)
	#CanDeviceLibrary.chicken_bit_enable(bus,device,func,0xb0,0x0)
	#CanDeviceLibrary.chicken_bit_enable(bus,device,func_can1,0xb0,0x0)

	#write cfg data for can 0
	CanDeviceLibrary.writePciConfigSpace(bus, device, func)
	CanDeviceLibrary.writePciConfigSpace(bus, device, func_can1)
	CanDeviceLibrary.printPciConfigSpace(bus, device, func)
	CanDeviceLibrary.printPciConfigSpace(bus, device, func_can1)
	
	#send data from can0 to can1
	
	CanDeviceLibrary.clearRAM_control(m_bar = can0_bar, clearRAM_enable = 1)


	CanDeviceLibrary.can_end_communication(m_bar = can0_bar)
	CanDeviceLibrary.can_setup(m_bar = can0_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 2, anfs = 2, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)
    
   
	CanDeviceLibrary.retransmission_control(m_bar = can0_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can0_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can0_bar)


	#can-1 setup
	CanDeviceLibrary.clearRAM_control(m_bar = can1_bar, clearRAM_enable = 1)
	CanDeviceLibrary.can_end_communication(m_bar = can1_bar)

	CanDeviceLibrary.can_setup(m_bar = can1_bar, rxf0c_elements = 64, rxf1c = 0, rxf1c_elements = 64, rxbuff_elements = 64, tbds = 7, flssa = 0x0, lss = 128, 
	lse = 64, flesa = 0x200, eidm = 0, f0sa = 0x400, f1sa = 0x640, rbsa = 0x2800, f0ds = 7, f1ds = 7, rbds = 7, 
	efsa = 0x3A00, efs = 32, efwm = 0, tbsa = 0x3B00, ndtb = 32, tbqs = 0, tbqm = 0, fdoe = 0, brse = 0, ntseg2 = 0x50, 
	ntseg1 = 0x2d, nbrp = 1, nsjw = 0, fsjw = 0, ftseg2 = 0x4, ftseg1 = 0xd, fbrp = 0x3, tdc = 0, tdcf = 0, tdco = 0, rrfe = 0, rrfs = 0,
	anfe = 0, anfs = 0, tie = 0xFFFFFFFF, cfie = 0xFFFFFFFF, eint0 = 1, eint1 = 0, intrLine = 0)


	CanDeviceLibrary.retransmission_control(m_bar = can1_bar, retransmission_disable = 1)
	CanDeviceLibrary.loopback_control(m_bar = can1_bar, internal_loopback  = 0 , loopback_enable  = 0)
	CanDeviceLibrary.can_start_communication(m_bar = can1_bar)


	#create filter for can 1 
	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can1_bar, pos = 0, filt = val)

	val = CanDeviceLibrary.create11bitFilter(sft = 0x0, sfec = 0x1 , sfid1 = 0x0, ssync = 0, sfid2 = 0xa )
	CanDeviceLibrary.push11BitFilter(m_bar = can0_bar, pos = 0, filt = val)

	#create packet and send form can 0
	txbuf = CanDeviceLibrary.createTxPacket(can_id=0x07, rtr = 0, xtd = 0, esi = 0, mm = 0x1, dlc = 8, brs = 0, fdf = 0, tsce = 0, efc = 1, txbuf = txbuf, tx_data = tx_data, pos = 0)
	CanDeviceLibrary.pushTxPacketRam(m_bar = can0_bar, pos = 0, txbuf = txbuf)
	CanDeviceLibrary.pushTxPacketTxbar(m_bar = can0_bar, pos = 0)
	
	CanDeviceLibrary.verify_rx_tranceiver(m_bar = can1_bar, sfec = 0x1, pkt_cnt = 1, txbuf = txbuf)

	