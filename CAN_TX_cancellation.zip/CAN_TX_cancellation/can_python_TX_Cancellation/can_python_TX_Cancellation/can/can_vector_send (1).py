# INTEL CONFIDENTIAL
# Copyright 2024 Intel Corporation All Rights Reserved.
#
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and
# proprietary and confidential information of Intel Corporation and its
# suppliers and licensors, and is protected by worldwide copyright and trade
# secret laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery of
# the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing

import argparse
import contextlib

# pylint: disable=deprecated-module
import time

import re
import can
from can.bus import BusState
from can.interfaces.vector import get_channel_configs

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Receive CAN frame",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--fd", action="store_true")
    parser.add_argument("--brs", action="store_true")
    parser.add_argument("--remote-frame", action="store_true")
    parser.add_argument("--is-extended", action="store_true")
    parser.add_argument(
        "-c", "--can_bitrate", default=125000, help="CAN bitrate [bps]", type=int
    )
    parser.add_argument("-d", "--fd_bitrate", default=250000, help="FD bitrate [bps]", type=int)
    parser.add_argument("--nsjw", help="Nominal sjw", type=int)
    parser.add_argument("--ntseg1", help="Nominal tseg 1", type=int)
    parser.add_argument("--ntseg2", help="Nominal tseg 2", type=int)
    parser.add_argument("--dsjw", help="Data sjw", type=int)
    parser.add_argument("--dtseg1", help="Data tseg 1", type=int)
    parser.add_argument("--dtseg2", help="Data tseg 2", type=int)

    parser.add_argument("-a", "--arbitration_id", default=123, help="arbitration id", type=int)
    parser.add_argument("-l", "--data_length", help="Data length", type=int)
    parser.add_argument("--data", default=None, help="Data in hex string")

    args = vars(parser.parse_args())

    if args["fd"]:
        if args["nsjw"] is None:
            vector_bus = can.Bus(
                interface="vector",
                channel=0,
                bitrate=args["can_bitrate"],
                fd=True,
                data_bitrate=args["fd_bitrate"],
                is_extended_id=args["is_extended"],
            )
        else:
            vector_bus = can.Bus(
                interface="vector",
                channel=0,
                bitrate=args["can_bitrate"],
                fd=True,
                data_bitrate=args["fd_bitrate"],
                sjw_abr=args["nsjw"],
                tseg1_abr=args["ntseg1"],
                tseg2_abr=args["ntseg2"],
                sjw_dbr=args["dsjw"],
                tseg1_dbr=args["dtseg1"],
                tseg2_dbr=args["dtseg2"],
                is_extended_id=args["is_extended"],
            )
    else:
        vector_bus = can.Bus(interface="vector", channel=0, bitrate=args["can_bitrate"])

    with vector_bus as vector_can:
        for config in get_channel_configs():
            if "Virtual" not in config.name:
                with contextlib.suppress(AttributeError):
                    print(str(config.bus_params.canfd))

        with contextlib.suppress(NotImplementedError):
            vector_bus.state = BusState.PASSIVE

        print(f"VECTOR STATE:{vector_can.state}")
        print("start")

        arbitration_id = args["arbitration_id"]

        data = (
            range(args["data_length"])
            if args["data"] is None
            else [int(x, 16) for x in re.findall("[A-Fa-f\\d]{2}", args["data"])]
        )

        data_len = (
            (args["data_length"] if args["data_length"] else len(data))
            if args["fd"]
            else args["data_length"] if args["data_length"] <= 8 else 8
        )

        print(f"Sending arbitration_id: {arbitration_id}, data:{data}")

        vector_can.send(
            can.Message(
                arbitration_id=arbitration_id,
                data=data,
                dlc=data_len,
                is_fd=args["fd"],
                bitrate_switch=args["brs"],
                is_remote_frame=args["remote_frame"],
                is_extended_id=args["is_extended"],
            )
        )

        time.sleep(1)
        print("STOP SENDING")
