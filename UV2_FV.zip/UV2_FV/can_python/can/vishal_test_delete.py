import sys
import ctypes
import random
import time
import math

sys.path.append(r'C:\Intel\DAL')
import itpii
import pci2
import os
import threading 
from can_reg import *