from enum import Enum

class Define(Enum):
	DMA_CH0_RX_CONTROL = 0x3108
	DMA_CH0_TX_CONTROL = 0x3104
	SR_MII_STS = 0x1
	MPLLA_CTRL2 = 0x8073
	SOFT_RESET_MASK = 0x8000
	VR_MII_AN_CTRL = 0x8001
	DIG_CTRL1 = 0x8000
	TX_GENCTRL1 = 0x8031
	VCO_CAL_LD0 = 0x8092
	VCO_CAL_REF0 = 0x8096
	RX_EQ_CTRL4 = 0x805c
	TX_RATE_CTRL = 0x8034
	RX_RATE_CTRL = 0x8054
	TX_GENCTRL2 = 0x8032
	RX_GENCTRL2 = 0x8052
	MPLLB_CTRL2 = 0x8076
	RX_EQ_CTRL0 = 0x8058
	RX_CDR_CTRL1 = 0x8064
	RX_MISC_CTRL0 = 0x8069
	RX_GEN_CTRL4 = 0x8068
	RX_IQ_CTRL0 = 0x806b
	RX_EQ_CTRL5 = 0x805d
	TX_EQ_CTRL1 = 0x8037
	MPLL_CMN_CTRL = 0x8070
	RX_PPM_CTRL0 = 0x8065
	TX_GENCTRL0 = 0x8030
	RX_GENCTRL1 = 0x8051
	VR_MII_LINK_TIMER_CTRL = 0x800a
	SR_VSMMD_CTRL = 0x9
	DIG_STS = 0x8010
	VR_MII_AN_INTR_STS = 0x8002
	SR_MII_CTRL = 0x0
	MGBE_CONFIG3 = 0x1C

class Burst_Length(Enum):
	burst_length_1 = 0x0
	burst_length_4 = 0x2
	burst_length_16 = 0x8
	burst_length_128 = 0x64
	burst_length_256 = 0x128

class ADDRESS(Enum):
	source = 0x1
	destination = 0x2

class CONNECTION_TYPE(Enum):
	phy_loopback = 0x0
	transactor_loopback = 0x1

class MAC_LOOPBACK(Enum):
	no_mac_loopback = 0
	mac_loopback = 1

class TSN_SPEED(Enum):
	s1G = 0
	s2_5G = 1

class VIRTUAL_CHANNEL(Enum):
	virtual_channel0 = 0
	virtual_channel1 = 1

class QUEUE_NUMBERS(Enum):
	Q1 = 1
	Q2 = 2
	Q3 = 3
	Q4 = 4
	Q5 = 5
	Q6 = 6

class VLAN_TAG_EN(Enum):
	disable = 0
	enable = 1

class DMA_CHANNEL_NUM(Enum):
	Ch_Equ_1 = 0x1
	Ch_Equ_2 = 0x2
	Ch_Equ_3 = 0x3
	Ch_Equ_4 = 0x4
	Ch_Equ_5 = 0x5
	Ch_Equ_6 = 0x6

class TYPE_VLAN_1(Enum):
	cvlan_1 = 0x0
	svlan_1 = 0x1
	none_1 = 0x2

class VLAN_TAG(Enum):
	inner = 0x0
	outer = 0x1
	no_tag = 0x2

class VLAN_TAG_COMPARE(Enum):
	bits_16 = 0
	bits_12 = 1

class OPTS_DISS_TYP_CK(Enum):
	type_check_disable = 0
	type_check_enable = 1

class VLAN_NO(Enum):
	single_vlan = 0
	double_vlan = 1

class DMA_INTERRUPT_MODE(Enum):
	pulse = 0
	level = 1

class INV_MATCH(Enum):
	not_inverse = 0
	inverse = 1


def gasket_powerup_2_5G(m_bar: int, AN_CTRL_VAL: int, AN_CTRL_MASK: int):

    _PollCount = 0
    _tmp = 0
    _pvar = 0

    # Step: _default
    write_pcs(m_bar, 32769, 0xfffffffe, 0x1)
    write_pcs(m_bar, 32768, 0xffffdbfb, 0x2404)
    write_pcs(m_bar, 0, 0xffffeebf, 0x140)
    write_pcs(m_bar, 32914, 0xffffe000, 0x61b)
    write_pcs(m_bar, 32918, 0xffffff80, 0x6)
    write_pcs(m_bar, 32860, 0xfffffffe, 0x0)
    write_pcs(m_bar, 32820, 0xfffffff8, 0x2)
    write_pcs(m_bar, 32852, 0xfffffff8, 0x2)
    write_pcs(m_bar, 32818, 0xfffffcff, 0x100)
    write_pcs(m_bar, 32850, 0xfffffcff, 0x100)
    write_pcs(m_bar, 32883, 0xfffff8ff, 0x200)
    write_pcs(m_bar, 32817, 0xffffef0f, 0x10)
    write_pcs(m_bar, 32856, 0xffffffe0, 0x6)
    write_pcs(m_bar, 32868, 0xffffffee, 0x10)
    write_pcs(m_bar, 32873, 0xffffff00, 0x7)
    write_pcs(m_bar, 32872, 0xfffffeff, 0x100)
    write_pcs(m_bar, 32868, 0xfffffcff, 0x200)
    write_pcs(m_bar, 32875, 0xfffff0ff, 0x0)
    write_pcs(m_bar, 32861, 0xffffffcf, 0x0)
    write_pcs(m_bar, 32880, 0xffffffef, 0x0)
    write_pcs(m_bar, 32869, 0xffffe0e0, 0x1515)
    write_pcs(m_bar, 32816, 0xffffeeff, 0x1100)
    write_pcs(m_bar, 32849, 0xfffffeef, 0x110)
    write_pcs(m_bar, 32816, 0xffffeeff, 0x1000)
    write_pcs(m_bar, 32849, 0xfffffeef, 0x100)
    write_pcs(m_bar, 32817, 0xffffe8ef, 0x1510)
    write_pcs(m_bar, 32823, 0xffffffbf, 0x40)
    write_pcs(m_bar, 32769, AN_CTRL_MASK, AN_CTRL_VAL)
    write_pcs(m_bar, 32768, 0xffffd9fb, 0x2404)
    write_pcs(m_bar, 32778, 0xfffffffe, 0x1)
    mdio_write(m_bar, 0x1e, 9, 0x14, 0x2d, 0x16)
    write_pcs(m_bar, 0, 0xffffcebf, 0x1140)
    mdio_read(m_bar, 0x1f, 32770, 0x2d, 0x16)
    while True:
        _tmp = readreg(0x8002)
        _pvar = (_tmp & 0x00000001)
        _PollCount += 1
        if (_PollCount >= 10):  # check max count
            print " ERROR | Hit Maximum count:10 (LocalRef(tsn, RF<ice_tsn_device>) == BitVectorConst(True, True, BitVector<1>))"
        if (_pvar == 0x1):
            break
    write_pcs(m_bar, 32770, 0xfffffffe, 0x0)
    read_pcs(m_bar, 1)
    while True:
        _tmp = readreg(0x1)
        _pvar = ((_tmp & 0x0020) >> 5)
        _PollCount += 1
        if (_PollCount >= 10):  # check max count
            print " ERROR | Hit Maximum count:10 (LocalRef(tsn, RF<ice_tsn_device>) == BitVectorConst(True, True, BitVector<1>))"
        if (_pvar == 0x1):
            break


def gasket_powerup_1G(m_bar: int, AN_CTRL_VAL: int, AN_CTRL_MASK: int):

    pcs_read = 0
    _PollCount = 0
    _tmp = 0
    _pvar = 0

    # Step: _default
    pcs_read = read_pcs(m_bar, 0)
    write_pcs(m_bar, 32769, 0xfffffffe, 0x1)
    write_pcs(m_bar, 32817, 0xffffefff, 0x0)
    write_pcs(m_bar, 32914, 0xffffe000, 0x5b2)
    write_pcs(m_bar, 32918, 0xffffff80, 0x7)
    write_pcs(m_bar, 32860, 0xfffffffe, 0x0)
    write_pcs(m_bar, 32820, 0xfffffff8, 0x6)
    write_pcs(m_bar, 32852, 0xfffffff8, 0x3)
    write_pcs(m_bar, 32818, 0xfffffcff, 0x100)
    write_pcs(m_bar, 32850, 0xfffffcff, 0x100)
    write_pcs(m_bar, 32886, 0xfffffd00, 0x29e)
    write_pcs(m_bar, 32817, 0xffffffef, 0x10)
    write_pcs(m_bar, 32856, 0xffffffe0, 0x6)
    write_pcs(m_bar, 32868, 0xffffffee, 0x10)
    write_pcs(m_bar, 32873, 0xffffff00, 0x47)
    write_pcs(m_bar, 32872, 0xfffffeff, 0x100)
    write_pcs(m_bar, 32868, 0xfffffcff, 0x100)
    write_pcs(m_bar, 32875, 0xfffff0ff, 0x0)
    write_pcs(m_bar, 32861, 0xffffffcf, 0x0)
    write_pcs(m_bar, 32817, 0xffffefff, 0x0)
    write_pcs(m_bar, 32880, 0xffffffee, 0x11)
    write_pcs(m_bar, 32869, 0xffffe0e0, 0x1313)
    write_pcs(m_bar, 32816, 0xffffeeff, 0x1100)
    write_pcs(m_bar, 32849, 0xfffffeef, 0x110)
    write_pcs(m_bar, 32816, 0xffffeeff, 0x1000)
    write_pcs(m_bar, 32849, 0xfffffeef, 0x100)
    write_pcs(m_bar, 32817, 0xffffe8ef, 0x1510)
    write_pcs(m_bar, 32823, 0xffffffbf, 0x40)
    write_pcs(m_bar, 32769, AN_CTRL_MASK, AN_CTRL_VAL)
    write_pcs(m_bar, 32768, 0xffffd9ff, 0x2400)
    write_pcs(m_bar, 32778, 0xfffffffe, 0x1)
    mdio_write(m_bar, 0x1e, 9, 0x14, 0x2d, 0x16)
    write_pcs(m_bar, 0, 0xffffcebf, 0x1140)
    mdio_read(m_bar, 0x1f, 32770, 0x2d, 0x16)
    while True:
        _tmp = readreg(0x8002)
        _pvar = (_tmp & 0x00000001)
        _PollCount += 1
        if (_PollCount >= 10):  # check max count
            print " ERROR | Hit Maximum count:10 (LocalRef(tsn, RF<ice_tsn_device>) == BitVectorConst(True, True, BitVector<1>))"
        if (_pvar == 0x1):
            break
    write_pcs(m_bar, 32770, 0xfffffffe, 0x0)
    read_pcs(m_bar, 1)
    while True:
        _tmp = readreg(0x1)
        _pvar = ((_tmp & 0x0020) >> 5)
        _PollCount += 1
        if (_PollCount >= 10):  # check max count
            print " ERROR | Hit Maximum count:10 (LocalRef(tsn, RF<ice_tsn_device>) == BitVectorConst(True, True, BitVector<1>))"
        if (_pvar == 0x1):
            break


def ControllerInit(m_bar: int, address_hi: int, address_lo: int, vlan_tag_filter: int, _CONNECTION_TYPE: CONNECTION_TYPE, _ADDRESS: ADDRESS, _MAC_LOOPBACK: MAC_LOOPBACK, _TSN_SPEED: TSN_SPEED, _VIRTUAL_CHANNEL: VIRTUAL_CHANNEL, _QUEUE_NUMBERS: QUEUE_NUMBERS, _VLAN_TAG_EN: VLAN_TAG_EN, _DMA_CHANNEL_NUM: DMA_CHANNEL_NUM, _VLAN_TAG: VLAN_TAG, _VLAN_TAG_COMPARE: VLAN_TAG_COMPARE, _TYPE_VLAN_1: TYPE_VLAN_1, _OPTS_DISS_TYP_CK: OPTS_DISS_TYP_CK, _INV_MATCH: INV_MATCH, _VLAN_NO: VLAN_NO, _DMA_INTERRUPT_MODE: DMA_INTERRUPT_MODE):

    reg_val_32 = 0
    mac_address_0_h = 0
    mac_address_0_l = 0
    mac_address_1_h = 0
    mac_address_1_l = 0
    vc_en = 0

    # Step: 1
    reg_val_32 = readreg(0x94)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x94, reg_val_32)

    # Step: 2
    reg_val_32 = readreg(0x27c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfff0ffff) | (0x2 << 16))
    reg_val_32 = ((reg_val_32 & 0xfffffff0) | 0x3)
    writereg(0x27c, reg_val_32)

    # Step: 3
    reg_val_32 = readreg(0x27c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfff0ffff) | (0x0 << 16))
    reg_val_32 = ((reg_val_32 & 0xfffffff0) | 0x3)
    writereg(0x27c, reg_val_32)
    reg_val_32 = readreg(0x300)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x0 << 16))
    writereg(0x300, reg_val_32)
    writereg(0x304, 0x00000000)

    # Step: 4
    if (_CONNECTION_TYPE == CONNECTION_TYPE.phy_loopback):
        mac_address_0_h = ((address_hi & 65535) & 0xffff)
        mac_address_0_l = (address_lo & 0xffffffff)
    else:
        mac_address_0_h = ((address_hi & 65535) & 0xffff)
        mac_address_0_l = (address_lo & 0xffffffff)
    reg_val_32 = readreg(0x300)
    reg_val_32 = ((reg_val_32 & 0xffff0000) | mac_address_0_h)
    writereg(0x300, reg_val_32)
    reg_val_32 = readreg(0x304)
    reg_val_32 = ((reg_val_32 & 0x00000000) | mac_address_0_l)
    writereg(0x304, reg_val_32)

    # Step: 5
    mac_address_1_h = ((address_hi & 65535) & 0xffff)
    reg_val_32 = readreg(0x308)
    if (_ADDRESS == ADDRESS.source):
        reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x1 << 30))
    else:
        reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x0 << 30))
    reg_val_32 = ((reg_val_32 & 0xc0ffffff) | (0x00 << 24))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x1 << 31))
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x0 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff0000) | mac_address_1_h)
    writereg(0x308, reg_val_32)
    mac_address_1_l = (address_lo & 0xffffffff)
    reg_val_32 = readreg(0x30c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | mac_address_1_l)
    writereg(0x30c, reg_val_32)

    # Step: 6
    reg_val_32 = readreg(0x0)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffff7) | (0x0 << 3))
    reg_val_32 = ((reg_val_32 & 0xffffff0f) | (0x0 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffff8ff) | (0x6 << 8))
    reg_val_32 = ((reg_val_32 & 0xfffff7ff) | (0x0 << 11))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x0 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffdfff) | (0x0 << 13))
    reg_val_32 = ((reg_val_32 & 0xfffeffff) | (0x0 << 16))
    reg_val_32 = ((reg_val_32 & 0xfffbffff) | (0x0 << 18))
    reg_val_32 = ((reg_val_32 & 0xfff7ffff) | (0x0 << 19))
    reg_val_32 = ((reg_val_32 & 0xff8fffff) | (0x3 << 20))
    reg_val_32 = ((reg_val_32 & 0xfeffffff) | (0x0 << 24))
    reg_val_32 = ((reg_val_32 & 0xfdffffff) | (0x0 << 25))
    reg_val_32 = ((reg_val_32 & 0xf7ffffff) | (0x0 << 27))
    reg_val_32 = ((reg_val_32 & 0xefffffff) | (0x0 << 28))
    writereg(0x0, reg_val_32)

    # Step: 7
    reg_val_32 = readreg(0x0)
    if (_TSN_SPEED == TSN_SPEED.s1G):
        reg_val_32 = ((reg_val_32 & 0x1fffffff) | (0x3 << 29))
    else:
        reg_val_32 = ((reg_val_32 & 0x1fffffff) | (0x2 << 29))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x0, reg_val_32)
    reg_val_32 = readreg(0x4)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffffb) | (0x0 << 2))
    reg_val_32 = ((reg_val_32 & 0xfffffff7) | (0x0 << 3))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x0 << 4))
    reg_val_32 = ((reg_val_32 & 0xffffffdf) | (0x0 << 5))
    reg_val_32 = ((reg_val_32 & 0xffffffbf) | (0x1 << 6))
    reg_val_32 = ((reg_val_32 & 0xffffff7f) | (0x1 << 7))
    reg_val_32 = ((reg_val_32 & 0xfffffeff) | (0x1 << 8))
    reg_val_32 = ((reg_val_32 & 0xfffffdff) | (0x1 << 9))
    reg_val_32 = ((reg_val_32 & 0xfffff7ff) | (0x1 << 11))
    reg_val_32 = ((reg_val_32 & 0xffff8fff) | (0x0 << 12))
    reg_val_32 = ((reg_val_32 & 0xffff7fff) | (0x0 << 15))
    reg_val_32 = ((reg_val_32 & 0xc000ffff) | (0x18d5 << 16))
    reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x0 << 30))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x0 << 31))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    if (_MAC_LOOPBACK == MAC_LOOPBACK.no_mac_loopback):
        reg_val_32 = ((reg_val_32 & 0xfffffbff) | (0x0 << 10))
    else:
        reg_val_32 = ((reg_val_32 & 0xfffffbff) | (0x1 << 10))
    writereg(0x4, reg_val_32)

    # Step: 8
    reg_val_32 = readreg(0x220)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffdfffff) | (0x1 << 21))
    writereg(0x220, reg_val_32)
    reg_val_32 = readreg(0x70)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if ((((((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x70, reg_val_32)
    reg_val_32 = readreg(0x74)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    elif (((((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x74, reg_val_32)
    reg_val_32 = readreg(0x78)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if ((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    if ((not (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1)) and ((((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6))):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x78, reg_val_32)
    reg_val_32 = readreg(0x7c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if (((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    if ((not (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1)) and (((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6))):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x7c, reg_val_32)
    reg_val_32 = readreg(0x80)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if ((((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    if ((not (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1)) and ((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6))):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x80, reg_val_32)
    reg_val_32 = readreg(0x84)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if (((((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4)) or (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5)):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x0 << 1))
    if ((_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6) and (not (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1))):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    writereg(0x84, reg_val_32)
    reg_val_32 = readreg(0x90)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x90, reg_val_32)
    reg_val_32 = readreg(0xb4)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffff7) | (0x1 << 3))
    reg_val_32 = ((reg_val_32 & 0xffffbfff) | (0x1 << 14))
    reg_val_32 = ((reg_val_32 & 0xffffdfff) | (0x1 << 13))
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffffb) | (0x1 << 2))
    writereg(0xb4, reg_val_32)
    writereg(0x0, 0x00000000)
    reg_val_32 = readreg(0x8)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x1 << 31))
    reg_val_32 = ((reg_val_32 & 0xfffeffff) | (_VLAN_TAG_EN << 16))
    reg_val_32 = ((reg_val_32 & 0xffffffbf) | (0x1 << 6))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x8, reg_val_32)
    reg_val_32 = readreg(0xa0)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q1):
        reg_val_32 = ((reg_val_32 & 0xfffffffc) | 0x2)
        reg_val_32 = ((reg_val_32 & 0xfffffff3) | (0x0 << 2))
        reg_val_32 = ((reg_val_32 & 0xffffffcf) | (0x0 << 4))
        reg_val_32 = ((reg_val_32 & 0xffffffcf) | (0x0 << 4))
        reg_val_32 = ((reg_val_32 & 0xffffff3f) | (0x0 << 6))
        reg_val_32 = ((reg_val_32 & 0xfffffcff) | (0x0 << 8))
    elif (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q2):
        reg_val_32 = ((reg_val_32 & 0xfffffff3) | (0x2 << 2))
    elif (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q3):
        reg_val_32 = ((reg_val_32 & 0xffffffcf) | (0x2 << 4))
    elif (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q4):
        reg_val_32 = ((reg_val_32 & 0xffffffcf) | (0x2 << 4))
    elif (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q5):
        reg_val_32 = ((reg_val_32 & 0xffffff3f) | (0x2 << 6))
    elif (_QUEUE_NUMBERS == QUEUE_NUMBERS.Q6):
        reg_val_32 = ((reg_val_32 & 0xfffffcff) | (0x2 << 8))
    writereg(0xa0, reg_val_32)
    reg_val_32 = readreg(0xa8)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffffff00) | 0x01)
    reg_val_32 = ((reg_val_32 & 0xffff00ff) | (0x02 << 8))
    reg_val_32 = ((reg_val_32 & 0xff00ffff) | (0x04 << 16))
    reg_val_32 = ((reg_val_32 & 0x00ffffff) | (0x08 << 24))
    writereg(0xa8, reg_val_32)
    reg_val_32 = readreg(0xac)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffffff00) | 0x10)
    reg_val_32 = ((reg_val_32 & 0xffff00ff) | (0x20 << 8))
    writereg(0xac, reg_val_32)
    if (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_1):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x0000
    elif (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_2):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x0202
    elif (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_3):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x0404
    elif (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_4):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x0c0c
    elif (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_5):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x1010
    elif (_DMA_CHANNEL_NUM == DMA_CHANNEL_NUM.Ch_Equ_6):
        if (_VIRTUAL_CHANNEL == VIRTUAL_CHANNEL.virtual_channel1):
            vc_en = 0x2020
    mdio_write(m_bar, 0x1c, 28, vc_en, 0x16, 0x15)
    reg_val_32 = readreg(0x54)
    if (_VLAN_TAG == VLAN_TAG.inner):
        reg_val_32 = ((reg_val_32 & 0xffefffff) | (0x1 << 20))
    else:
        reg_val_32 = ((reg_val_32 & 0xffefffff) | (0x0 << 20))
    reg_val_32 = ((reg_val_32 & 0xfdffffff) | (0x0 << 25))
    reg_val_32 = ((reg_val_32 & 0xfeffffff) | (0x0 << 24))
    reg_val_32 = ((reg_val_32 & 0xfff7ffff) | (_TYPE_VLAN_1 << 19))
    reg_val_32 = ((reg_val_32 & 0xfffdffff) | (_VLAN_TAG_COMPARE << 17))
    reg_val_32 = ((reg_val_32 & 0xfffeffff) | (_VLAN_TAG_EN << 16))
    reg_val_32 = ((reg_val_32 & 0xffff0000) | vlan_tag_filter)
    writereg(0x54, reg_val_32)
    reg_val_32 = readreg(0x50)
    if (_VLAN_TAG == VLAN_TAG.inner):
        reg_val_32 = ((reg_val_32 & 0xf7ffffff) | (0x1 << 27))
        reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x1 << 31))
    else:
        reg_val_32 = ((reg_val_32 & 0xf7ffffff) | (0x0 << 27))
        reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x0 << 31))
    reg_val_32 = ((reg_val_32 & 0xfbffffff) | (_VLAN_NO << 26))
    reg_val_32 = ((reg_val_32 & 0xfdffffff) | (0x0 << 25))
    reg_val_32 = ((reg_val_32 & 0xfeffffff) | (0x1 << 24))
    reg_val_32 = ((reg_val_32 & 0xffefffff) | (_OPTS_DISS_TYP_CK << 20))
    reg_val_32 = ((reg_val_32 & 0xfff7ffff) | (_TYPE_VLAN_1 << 19))
    reg_val_32 = ((reg_val_32 & 0xfffbffff) | (_TYPE_VLAN_1 << 18))
    reg_val_32 = ((reg_val_32 & 0xfffdffff) | (_INV_MATCH << 17))
    reg_val_32 = ((reg_val_32 & 0xfffeffff) | (_VLAN_TAG_COMPARE << 16))
    reg_val_32 = ((reg_val_32 & 0xffffff83) | (0x00 << 2))
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x50, reg_val_32)
    reg_val_32 = readreg(0x1000)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffb) | (0x1 << 2))
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    reg_val_32 = ((reg_val_32 & 0xfffffffb) | (0x0 << 2))
    writereg(0x1000, reg_val_32)
    reg_val_32 = readreg(0x3000)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    reg_val_32 = ((reg_val_32 & 0xffffffe3) | (0x0 << 2))
    if (_DMA_INTERRUPT_MODE == DMA_INTERRUPT_MODE.pulse):
        reg_val_32 = ((reg_val_32 & 0xffff3fff) | (0x0 << 14))
    elif (_DMA_INTERRUPT_MODE == DMA_INTERRUPT_MODE.level):
        reg_val_32 = ((reg_val_32 & 0xffff3fff) | (0x1 << 14))
    writereg(0x3000, reg_val_32)


def sw_reset(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3000)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3000, reg_val_32)


def TSN_dma_tx_init(m_bar: int, _Burst_Length: Burst_Length):

    reg_val_32 = 0

    # Step: 1
    reg_val_32 = readreg(0x3004)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffe0ffff) | (0x0f << 16))
    reg_val_32 = ((reg_val_32 & 0xe0ffffff) | (0x0f << 24))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    if (_Burst_Length == 0):
        reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    elif (_Burst_Length == 1):
        reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    elif (_Burst_Length == 2):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    elif (_Burst_Length == 8):
        reg_val_32 = ((reg_val_32 & 0xfffffff7) | (0x1 << 3))
    elif (_Burst_Length == 100):
        reg_val_32 = ((reg_val_32 & 0xffffffbf) | (0x1 << 6))
    elif (_Burst_Length == 296):
        reg_val_32 = ((reg_val_32 & 0xffffff7f) | (0x1 << 7))
    writereg(0x3004, reg_val_32)

    # Step: 3
    reg_val_32 = readreg(0x3040)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffff8) | 0x1)
    writereg(0x3040, reg_val_32)


def TSN_dma_rx_init(m_bar: int, _Burst_Length: Burst_Length):

    reg_val_32 = 0
    _pvar = 0

    # Step: 1
    reg_val_32 = readreg(0x3004)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffe0ffff) | (0x0f << 16))
    reg_val_32 = ((reg_val_32 & 0xe0ffffff) | (0x0f << 24))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    if (_Burst_Length == 0):
        reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    elif (_Burst_Length == 1):
        reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    elif (_Burst_Length == 2):
        reg_val_32 = ((reg_val_32 & 0xfffffffd) | (0x1 << 1))
    elif (_Burst_Length == 8):
        reg_val_32 = ((reg_val_32 & 0xfffffff7) | (0x1 << 3))
    elif (_Burst_Length == 100):
        reg_val_32 = ((reg_val_32 & 0xffffffbf) | (0x1 << 6))
    elif (_Burst_Length == 296):
        reg_val_32 = ((reg_val_32 & 0xffffff7f) | (0x1 << 7))
    writereg(0x3004, reg_val_32)

    # Step: 3
    reg_val_32 = readreg(0x3044)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffffc) | 0x1)
    writereg(0x3044, reg_val_32)
    while True:
        _pvar = readreg(0x1)
        if (_pvar == 0x0001):
            break


def mac_address_0_config_Mike(m_bar: int, address_hi: int, address_lo: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x300)
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x0 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff0000) | address_hi)
    writereg(0x300, reg_val_32)
    reg_val_32 = readreg(0x304)
    reg_val_32 = ((reg_val_32 & 0x00000000) | address_lo)
    writereg(0x304, reg_val_32)


def mac_address_1_config_Mike(m_bar: int, address_hi: int, address_lo: int, _ADDRESS: ADDRESS):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x308)
    if (_ADDRESS == ADDRESS.source):
        reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x1 << 30))
    else:
        reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x0 << 30))
    reg_val_32 = ((reg_val_32 & 0xc0ffffff) | (0x00 << 24))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x1 << 31))
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x0 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff0000) | address_hi)
    writereg(0x308, reg_val_32)
    reg_val_32 = readreg(0x30c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | address_lo)
    writereg(0x30c, reg_val_32)


def TxGo(m_bar: int, channel: int):

    # Step: _default
    if (channel == 0x01):
        TxGo1(m_bar)
    elif (channel == 0x02):
        TxGo2(m_bar)
    elif (channel == 0x03):
        TxGo3(m_bar)
    elif (channel == 0x04):
        TxGo4(m_bar)
    elif (channel == 0x05):
        TxGo5(m_bar)
    elif (channel == 0x06):
        TxGo6(m_bar)


def TxGoAll(m_bar: int):

    # Step: _default
    TxGo1(m_bar)
    TxGo2(m_bar)
    TxGo3(m_bar)
    TxGo4(m_bar)
    TxGo5(m_bar)
    TxGo6(m_bar)


def TxGo1(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3100)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3100, reg_val_32)


def TxGo2(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3184)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3184, reg_val_32)


def TxGo3(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3204)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3204, reg_val_32)


def TxGo4(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x325c)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x325c, reg_val_32)


def TxGo5(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3304)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3304, reg_val_32)


def TxGo6(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3384)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffffefff) | (0x1 << 12))
    reg_val_32 = ((reg_val_32 & 0xffffffef) | (0x1 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3384, reg_val_32)


def TxStop(m_bar: int, channel: int):

    # Step: _default
    if (channel == 0x01):
        TxStop1(m_bar)
    elif (channel == 0x02):
        TxStop2(m_bar)
    elif (channel == 0x03):
        TxStop3(m_bar)
    elif (channel == 0x04):
        TxStop4(m_bar)
    elif (channel == 0x05):
        TxStop5(m_bar)
    elif (channel == 0x06):
        TxStop6(m_bar)


def TxStop1(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3100)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3100, reg_val_32)


def TxStop2(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3184)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3184, reg_val_32)


def TxStop3(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3204)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3204, reg_val_32)


def TxStop4(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x325c)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x325c, reg_val_32)


def TxStop5(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3304)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3304, reg_val_32)


def TxStop6(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3384)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3384, reg_val_32)


def RxGo(m_bar: int, channel: int):

    # Step: _default
    if (channel == 0x01):
        RxGo1(m_bar)
    elif (channel == 0x02):
        RxGo2(m_bar)
    elif (channel == 0x03):
        RxGo3(m_bar)
    elif (channel == 0x04):
        RxGo4(m_bar)
    elif (channel == 0x05):
        RxGo5(m_bar)
    elif (channel == 0x06):
        RxGo6(m_bar)


def RxGoAll(m_bar: int):

    # Step: _default
    RxGo1(m_bar)
    RxGo2(m_bar)
    RxGo3(m_bar)
    RxGo4(m_bar)
    RxGo5(m_bar)
    RxGo6(m_bar)


def RxGo1(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3108)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3108, reg_val_32)


def RxGo2(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3188)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3188, reg_val_32)


def RxGo3(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3208)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3208, reg_val_32)


def RxGo4(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3288)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3288, reg_val_32)


def RxGo5(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3388)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3388, reg_val_32)


def RxGo6(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3388)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xffc0ffff) | (0x10 << 16))
    reg_val_32 = ((reg_val_32 & 0xffff800f) | (0x100 << 4))
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x1)
    writereg(0x3388, reg_val_32)


def RxStop(m_bar: int, channel: int):

    # Step: _default
    if (channel == 0x01):
        RxStop1(m_bar)
    elif (channel == 0x02):
        RxStop2(m_bar)
    elif (channel == 0x03):
        RxStop3(m_bar)
    elif (channel == 0x04):
        RxStop4(m_bar)
    elif (channel == 0x05):
        RxStop5(m_bar)
    elif (channel == 0x06):
        RxStop6(m_bar)


def RxStopAll(m_bar: int):

    # Step: _default
    RxStop1(m_bar)
    RxStop2(m_bar)
    RxStop3(m_bar)
    RxStop4(m_bar)
    RxStop5(m_bar)
    RxStop6(m_bar)


def RxStop1(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3108)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3108, reg_val_32)


def RxStop2(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3188)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3188, reg_val_32)


def RxStop3(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3208)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3208, reg_val_32)


def RxStop4(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3288)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3288, reg_val_32)


def RxStop5(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3308)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3308, reg_val_32)


def RxStop6(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x3388)
    reg_val_32 = ((reg_val_32 & 0xfffffffe) | 0x0)
    writereg(0x3388, reg_val_32)


def mtl_rxq_dma_map_cfg(m_bar: int):

    reg_val_32 = 0

    # Step: _default
    reg_val_32 = readreg(0x1030)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffff8) | 0x0)
    reg_val_32 = ((reg_val_32 & 0xffffff7f) | (0x0 << 7))
    reg_val_32 = ((reg_val_32 & 0xfffff8ff) | (0x1 << 8))
    reg_val_32 = ((reg_val_32 & 0xffff7fff) | (0x0 << 15))
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x2 << 16))
    reg_val_32 = ((reg_val_32 & 0xff7fffff) | (0x0 << 23))
    reg_val_32 = ((reg_val_32 & 0xf8ffffff) | (0x3 << 24))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x0 << 31))
    writereg(0x1030, reg_val_32)
    reg_val_32 = readreg(0x1034)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    reg_val_32 = ((reg_val_32 & 0xfffffff8) | 0x4)
    reg_val_32 = ((reg_val_32 & 0xffffff7f) | (0x0 << 7))
    reg_val_32 = ((reg_val_32 & 0xfffff8ff) | (0x5 << 8))
    reg_val_32 = ((reg_val_32 & 0xffff7fff) | (0x0 << 15))
    reg_val_32 = ((reg_val_32 & 0xfff8ffff) | (0x6 << 16))
    reg_val_32 = ((reg_val_32 & 0xff7fffff) | (0x0 << 23))
    reg_val_32 = ((reg_val_32 & 0xf8ffffff) | (0x7 << 24))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x0 << 31))
    writereg(0x1034, reg_val_32)


def program_mdio(m_bar: int, dev: int, addr: int, opcode: int, data: int, clause: int, phy_ad: int):

    reg_val_32 = 0
    _PollCount = 0
    _tmp = 0
    _pvar = 0

    # Step: _default
    reg_val_32 = readreg(0x200)
    reg_val_32 = ((reg_val_32 & 0x00000000) | 0x00000000)
    if ((clause == 0x00000016) or (clause == 0x0000002d)):
        reg_val_32 = ((reg_val_32 & 0xffff0000) | addr)
        reg_val_32 = ((reg_val_32 & 0xffe0ffff) | (phy_ad << 16))
        reg_val_32 = ((reg_val_32 & 0xfc1fffff) | (dev << 21))
    writereg(0x200, reg_val_32)
    reg_val_32 = readreg(0x204)
    reg_val_32 = ((reg_val_32 & 0xfffcffff) | (opcode << 16))
    reg_val_32 = ((reg_val_32 & 0xffc7ffff) | (0x4 << 19))
    reg_val_32 = ((reg_val_32 & 0xffbfffff) | (0x1 << 22))
    reg_val_32 = ((reg_val_32 & 0xbfffffff) | (0x0 << 30))
    reg_val_32 = ((reg_val_32 & 0x7fffffff) | (0x0 << 31))
    reg_val_32 = ((reg_val_32 & 0xffff0000) | data)
    writereg(0x204, reg_val_32)
    while True:
        _tmp = readreg(0x204)
        _pvar = ((_tmp & 0x80000000) >> 31)
        _PollCount += 1
        if (_PollCount >= 10):  # check max count
            print " ERROR | Hit Maximum count:10 (LocalRef(tsn, RF<ice_tsn_device>) == BitVectorConst(4, 4, BitVector<3>))"
        if (_pvar == 0x4):
            break


def mdio_read(m_bar: int, dev: int, addr: int, clause: int, phy_ad: int):

    data = 0
    opcode = 0
    reg_val_32 = 0
    mdio_data_read = 0

    # Step: _default
    data = 0x0
    opcode = 0x3
    program_mdio(m_bar, dev, addr, 0x3, 0x0, clause, phy_ad)
    reg_val_32 = readreg(0x204)
    mdio_data_read = (reg_val_32 & 0xffffffff)
    mdio_data_read = ((mdio_data_read & 65535) & 0xffff)
    return mdio_data_read


def mdio_write(m_bar: int, dev: int, addr: int, data: int, clause: int, phy_ad: int):

    opcode = 0

    # Step: _default
    opcode = 0x1
    program_mdio(m_bar, dev, addr, 0x1, data, clause, phy_ad)


def write_pcs(m_bar: int, addr: int, and_mask: int, or_mask: int):

    pcs_val = 0

    # Step: _default
    pcs_val = mdio_read(m_bar, 0x1f, addr, 0x2d, 0x16)
    pcs_val = (((pcs_val & 65535) & and_mask) | or_mask)
    mdio_write(m_bar, 0x1f, addr, pcs_val, 0x2d, 0x16)


def read_pcs(m_bar: int, addr: int):

    pcs_val = 0

    # Step: _default
    pcs_val = mdio_read(m_bar, 0x1f, addr, 0x2d, 0x16)
    return pcs_val
